# WorkForce360 - FastAPI Backend System

## Overview
WorkForce360 is a comprehensive FastAPI backend system designed to manage casual labour tracking, attendance, payroll, PPE, and compliance across multiple plants for a chemical manufacturing company.

## Project Architecture
```
app/
├── api/                    # FastAPI route handlers
│   ├── plants.py          # Plant management endpoints
│   ├── departments.py     # Department management endpoints
│   ├── contractors.py     # Contractor management endpoints
│   ├── labours.py        # Labour management endpoints
│   ├── attendance.py     # Attendance tracking endpoints
│   ├── payroll.py        # Payroll management endpoints
│   ├── grades.py         # Grade management endpoints
│   └── ppe_rates.py      # PPE rates management endpoints
├── crud/                  # Database CRUD operations
├── db/
│   ├── models/           # SQLAlchemy ORM models
│   │   ├── base.py      # Database base configuration
│   │   └── models.py    # All database models
│   └── session.py       # Database session management
├── schemas/              # Pydantic request/response models
├── services/             # Business logic services
│   └── payroll_service.py # Payroll calculation logic
├── tasks/                # Background tasks
│   └── background_tasks.py # Celery background tasks
├── utils/                # Helper utilities
│   └── pdf_export.py    # PDF generation utilities
├── alembic/              # Database migrations
└── main.py              # FastAPI application entry point
```

## Key Features

### Master Data Management
- **Plants**: Manage manufacturing plants with unique codes and locations
- **Departments**: Organize departments within plants with cost center codes
- **Contractors**: Track contractor information and contact details
- **Casual Grades**: Define wage grades with PF, ESIC, bonus configurations
- **PPE Rates**: Manage Personal Protective Equipment rates

### Labour Management
- **Casual Labour**: Track employee details with plant, department, and grade assignments
- **Employee ID**: Unique identification for each labour

### Attendance Tracking
- **Daily Attendance**: Track presence, hours worked, overtime
- **Shift Types**: Support for 8Hr and 12Hr shifts
- **Holiday Management**: Track holiday attendance
- **Bulk Import**: Import attendance data from external systems

### Payroll Processing
- **Automated Calculation**: Calculate payroll based on attendance and grade rules
- **Deductions**: PF, ESIC deductions based on grade configuration
- **Allowances**: Bonus, attendance incentives, PPE allowances
- **Background Processing**: Async payroll generation for large datasets
- **PDF Export**: Generate payroll reports in PDF format

## API Endpoints

### Core APIs
- `GET/POST /api/v1/plants` - Plant management
- `GET/POST /api/v1/departments` - Department management
- `GET/POST /api/v1/contractors` - Contractor management
- `GET/POST /api/v1/labours` - Labour management

### Attendance APIs
- `POST /api/v1/attendance/import-summary` - Bulk import attendance
- `GET /api/v1/attendance/{labour_id}` - Get labour attendance by month/year
- `POST /api/v1/attendance/` - Create single attendance record

### Payroll APIs
- `POST /api/v1/payroll/generate` - Generate payroll (background task)
- `GET /api/v1/payroll/{labour_id}` - Get labour payroll by month/year
- `GET /api/v1/payroll/download/` - Export payroll to PDF

### Configuration APIs
- `GET/POST/PATCH /api/v1/grades` - Grade management
- `GET/POST/PATCH /api/v1/ppe-rates` - PPE rate management

## Database Schema

### Core Tables
- `plants` - Manufacturing plants
- `departments` - Plant departments
- `contractors` - Labour contractors
- `casual_grades` - Wage grade definitions
- `ppe_rates` - PPE rate definitions
- `casual_labours` - Employee records
- `attendance_summary` - Daily attendance records
- `payroll_records` - Monthly payroll calculations

### Key Relationships
- Plant → Departments → Labours
- Contractor → Labours
- Grade → Labours (wage calculations)
- PPE Rate → Labours (allowance calculations)
- Labour → Attendance → Payroll

## Technology Stack
- **Framework**: FastAPI 0.116.1
- **ORM**: SQLAlchemy 2.0.43
- **Database**: PostgreSQL (Replit managed)
- **Migrations**: Alembic 1.16.5
- **Validation**: Pydantic 2.11.7
- **Background Tasks**: Celery 5.5.3
- **PDF Generation**: ReportLab 4.4.3
- **Excel Export**: OpenPyXL 3.1.5

## Recent Changes
- ✅ Set up complete FastAPI project structure
- ✅ Implemented all SQLAlchemy models with proper relationships
- ✅ Created Pydantic schemas for request/response validation
- ✅ Built comprehensive CRUD operations for all entities
- ✅ Developed FastAPI route handlers with proper error handling
- ✅ Implemented payroll calculation business logic
- ✅ Added background task support for async operations
- ✅ Created PDF export utilities for payroll reports
- ✅ Configured Alembic for database migrations
- ✅ Set up PostgreSQL database with initial migration
- ✅ Application running successfully on port 5000

### **Latest Architectural Refactoring (September 2025)**
- ✅ **Dual Database Architecture**: Added MS SQL integration via `attendance_session.py` for external attendance punch data
- ✅ **CRUD Layer Refactoring**: Removed all business logic, keeping only raw database operations
- ✅ **Enhanced Services Layer**: Created dedicated service classes with complete business rules:
  - `PlantService`: Plant management with validation and department relationships
  - `LabourService`: Employee lifecycle management with comprehensive validations  
  - `AttendanceService`: MS SQL integration for punch data import and processing
  - `EnhancedPayrollService`: Complete payroll calculations with PF, ESIC, bonus, incentives
- ✅ **API Layer Refactoring**: Updated all routes to call Services only (never CRUD directly)
- ✅ **MS SQL Integration**: External attendance system integration with date-based import
- ✅ **Enhanced Attendance APIs**: Calendar views, bulk import from MS SQL, manual entry
- ✅ **Advanced Payroll APIs**: Real-time calculations, period summaries, background generation

## API Documentation
- **Swagger UI**: http://localhost:5000/docs
- **ReDoc**: http://localhost:5000/redoc
- **Health Check**: http://localhost:5000/health

## Development Notes
- Database migrations are handled via Alembic
- All models include proper foreign key relationships
- Payroll calculation includes PF, ESIC, bonus, and attendance incentives
- Background tasks use Celery for scalable processing
- PDF exports support custom formatting and plant-wise filtering

### **Architectural Guidelines**
- **CRUD Layer**: Raw database operations only, no business logic
- **Services Layer**: All business rules, validations, and complex logic
- **API Layer**: Thin routes that only call Services (never CRUD directly)
- **Dual Database**: PostgreSQL (main operations) + MS SQL (external attendance data)
- **Error Handling**: Comprehensive validation with descriptive error messages
- **Background Processing**: Scalable payroll generation for large datasets

## User Preferences
- Focus on production-ready code with proper error handling
- Comprehensive business logic for payroll calculations
- Scalable architecture supporting multiple plants
- Clean separation of concerns with services layer