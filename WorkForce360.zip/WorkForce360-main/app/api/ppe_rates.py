from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from db.session import get_db
from schemas import PPERate, PPERateCreate, PPERateUpdate
from crud import ppe_rate

router = APIRouter(prefix="/ppe-rates", tags=["ppe-rates"])

@router.get("/", response_model=List[PPERate])
def read_ppe_rates(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return ppe_rate.get_multi(db, skip=skip, limit=limit)

@router.post("/", response_model=PPERate)
def create_ppe_rate(ppe_rate_in: PPERateCreate, db: Session = Depends(get_db)):
    existing_ppe = ppe_rate.get_by_code(db, code=ppe_rate_in.code)
    if existing_ppe:
        raise HTTPException(status_code=400, detail="PPE rate with this code already exists")
    return ppe_rate.create(db, obj_in=ppe_rate_in)

@router.patch("/{ppe_code}", response_model=PPERate)
def update_ppe_rate(ppe_code: str, ppe_rate_in: PPERateUpdate, db: Session = Depends(get_db)):
    db_ppe_rate = ppe_rate.get_by_code(db, code=ppe_code)
    if db_ppe_rate is None:
        raise HTTPException(status_code=404, detail="PPE rate not found")
    return ppe_rate.update(db, db_obj=db_ppe_rate, obj_in=ppe_rate_in)