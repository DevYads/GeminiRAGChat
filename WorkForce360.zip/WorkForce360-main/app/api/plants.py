from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from db.session import get_db
from schemas import Plant, PlantCreate, PlantUpdate
from services.plant_service import PlantService

router = APIRouter(prefix="/plants", tags=["plants"])

@router.get("/", response_model=List[Plant])
def read_plants(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """Get all plants - thin API layer calling service"""
    return PlantService.get_all_plants(db, skip=skip, limit=limit)

@router.post("/", response_model=Plant)  
def create_plant(plant_in: PlantCreate, db: Session = Depends(get_db)):
    """Create new plant - thin API layer calling service"""
    try:
        return PlantService.create_plant(db, plant_in)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/{plant_id}", response_model=Plant)
def read_plant(plant_id: int, db: Session = Depends(get_db)):
    """Get plant by ID - thin API layer calling service"""
    plant = PlantService.get_plant_by_id(db, plant_id)
    if plant is None:
        raise HTTPException(status_code=404, detail="Plant not found")
    return plant

@router.get("/{plant_id}/details")
def read_plant_with_departments(plant_id: int, db: Session = Depends(get_db)):
    """Get plant with departments - business logic from service"""
    result = PlantService.get_plant_with_departments(db, plant_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Plant not found")
    return result

@router.put("/{plant_id}", response_model=Plant)
def update_plant(plant_id: int, plant_in: PlantUpdate, db: Session = Depends(get_db)):
    """Update plant - thin API layer calling service"""
    try:
        result = PlantService.update_plant(db, plant_id, plant_in)
        if result is None:
            raise HTTPException(status_code=404, detail="Plant not found")
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))