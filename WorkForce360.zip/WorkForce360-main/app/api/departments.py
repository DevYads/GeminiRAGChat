from typing import List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from db.session import get_db
from schemas import Department, DepartmentCreate, DepartmentUpdate
from crud import department

router = APIRouter(prefix="/departments", tags=["departments"])

@router.get("/", response_model=List[Department])
def read_departments(
    plant_id: int = Query(None, description="Filter by plant ID"),
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    if plant_id:
        return department.get_by_plant(db, plant_id=plant_id)
    return department.get_multi(db, skip=skip, limit=limit)

@router.post("/", response_model=Department)
def create_department(department_in: DepartmentCreate, db: Session = Depends(get_db)):
    return department.create(db, obj_in=department_in)

@router.get("/{department_id}", response_model=Department)
def read_department(department_id: int, db: Session = Depends(get_db)):
    db_department = department.get(db, id=department_id)
    if db_department is None:
        raise HTTPException(status_code=404, detail="Department not found")
    return db_department

@router.put("/{department_id}", response_model=Department)
def update_department(department_id: int, department_in: DepartmentUpdate, db: Session = Depends(get_db)):
    db_department = department.get(db, id=department_id)
    if db_department is None:
        raise HTTPException(status_code=404, detail="Department not found")
    return department.update(db, db_obj=db_department, obj_in=department_in)