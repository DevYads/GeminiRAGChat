from typing import List
from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from sqlalchemy.orm import Session

from db.session import get_db
from schemas import PayrollRecord
from services.enhanced_payroll_service import EnhancedPayrollService
from tasks.background_tasks import generate_payroll_task

router = APIRouter(prefix="/payroll", tags=["payroll"])

@router.post("/generate")
def generate_payroll_for_period(
    month: int = Query(..., description="Month (1-12)"),
    year: int = Query(..., description="Year"),
    plant_id: int = Query(None, description="Plant ID filter"),
    background_tasks: BackgroundTasks = None,
    db: Session = Depends(get_db)
):
    """Generate payroll for all labours in period - business logic from service"""
    if background_tasks:
        # Run in background for large datasets
        background_tasks.add_task(generate_payroll_task, month, year, plant_id)
        return {"message": "Payroll generation started in background", "month": month, "year": year}
    else:
        # Run synchronously for smaller datasets
        try:
            result = EnhancedPayrollService.generate_payroll_for_period(db, month, year, plant_id)
            return result
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Payroll generation failed: {str(e)}")

@router.get("/{labour_id}")
def get_labour_payroll_details(
    labour_id: int,
    month: int = Query(..., description="Month (1-12)"),
    year: int = Query(..., description="Year"),
    db: Session = Depends(get_db)
):
    """Get detailed payroll information - business logic from service"""
    details = EnhancedPayrollService.get_labour_payroll_details(db, labour_id, month, year)
    if details is None:
        raise HTTPException(status_code=404, detail="Payroll record not found")
    return details

@router.get("/{labour_id}/calculate")
def calculate_labour_payroll(
    labour_id: int,
    month: int = Query(..., description="Month (1-12)"),
    year: int = Query(..., description="Year"),
    db: Session = Depends(get_db)
):
    """Calculate payroll without saving - business logic from service"""
    try:
        calculation = EnhancedPayrollService.calculate_labour_payroll(db, labour_id, month, year)
        if calculation is None:
            raise HTTPException(status_code=404, detail="Labour not found or no attendance data")
        return calculation
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Calculation failed: {str(e)}")

@router.get("/summary/")
def get_payroll_summary(
    month: int = Query(..., description="Month (1-12)"),
    year: int = Query(..., description="Year"),
    plant_id: int = Query(None, description="Plant ID filter"),
    db: Session = Depends(get_db)
):
    """Get payroll summary for period - business analytics from service"""
    try:
        summary = EnhancedPayrollService.get_payroll_summary_by_period(db, month, year, plant_id)
        return summary
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Summary generation failed: {str(e)}")

@router.get("/download/")
def download_payroll_export(
    month: int = Query(..., description="Month (1-12)"),
    year: int = Query(..., description="Year"),
    plant_id: int = Query(None, description="Plant ID filter"),
    db: Session = Depends(get_db)
):
    """Export payroll to PDF - will be enhanced with PDF export utility"""
    try:
        summary = EnhancedPayrollService.get_payroll_summary_by_period(db, month, year, plant_id)
        
        if summary["total_records"] == 0:
            raise HTTPException(status_code=404, detail="No payroll records found for the specified period")
        
        # TODO: Implement PDF generation using utils/pdf_export.py
        return {
            "message": "PDF export will be implemented",
            "preview": {
                "month": month,
                "year": year,
                "plant_id": plant_id,
                "total_records": summary["total_records"],
                "total_net_pay": summary["summary"].get("total_net_pay", 0)
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")