from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from db.session import get_db
from schemas import CasualGrade, CasualGradeCreate, CasualGradeUpdate
from crud import grade

router = APIRouter(prefix="/grades", tags=["grades"])

@router.get("/", response_model=List[CasualGrade])
def read_grades(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return grade.get_multi(db, skip=skip, limit=limit)

@router.post("/", response_model=CasualGrade)
def create_grade(grade_in: CasualGradeCreate, db: Session = Depends(get_db)):
    existing_grade = grade.get_by_code(db, code=grade_in.code)
    if existing_grade:
        raise HTTPException(status_code=400, detail="Grade with this code already exists")
    return grade.create(db, obj_in=grade_in)

@router.patch("/{grade_id}", response_model=CasualGrade)
def update_grade(grade_id: int, grade_in: CasualGradeUpdate, db: Session = Depends(get_db)):
    db_grade = grade.get(db, id=grade_id)
    if db_grade is None:
        raise HTTPException(status_code=404, detail="Grade not found")
    return grade.update(db, db_obj=db_grade, obj_in=grade_in)