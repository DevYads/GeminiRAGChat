from typing import List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from db.session import get_db
from schemas import CasualLabour, CasualLabourCreate, CasualLabourUpdate
from services.labour_service import LabourService

router = APIRouter(prefix="/labours", tags=["labours"])

@router.get("/", response_model=List[CasualLabour])
def read_labours(
    plant_id: int = Query(None, description="Filter by plant ID"),
    contractor_id: int = Query(None, description="Filter by contractor ID"),
    active_only: bool = Query(True, description="Show only active labours"),
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Get labours with filters - thin API layer calling service"""
    filters = {}
    if plant_id:
        filters["plant_id"] = plant_id
    if contractor_id:
        filters["contractor_id"] = contractor_id
    if active_only:
        filters["active_status"] = True
        
    return LabourService.get_labours_by_filters(db, filters=filters, skip=skip, limit=limit)

@router.post("/", response_model=CasualLabour)
def create_labour(labour_in: CasualLabourCreate, db: Session = Depends(get_db)):
    """Create new labour - thin API layer calling service"""
    try:
        return LabourService.create_labour(db, labour_in)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/{labour_id}", response_model=CasualLabour)
def read_labour(labour_id: int, db: Session = Depends(get_db)):
    """Get labour by ID - thin API layer calling service"""
    labour = LabourService.get_labour_by_id(db, labour_id)
    if labour is None:
        raise HTTPException(status_code=404, detail="Labour not found")
    return labour

@router.get("/{labour_id}/details")
def read_labour_details(labour_id: int, db: Session = Depends(get_db)):
    """Get complete labour details - business logic from service"""
    details = LabourService.get_labour_details(db, labour_id)
    if details is None:
        raise HTTPException(status_code=404, detail="Labour not found")
    return details

@router.put("/{labour_id}", response_model=CasualLabour)
def update_labour(labour_id: int, labour_in: CasualLabourUpdate, db: Session = Depends(get_db)):
    """Update labour - thin API layer calling service"""
    try:
        result = LabourService.update_labour(db, labour_id, labour_in)
        if result is None:
            raise HTTPException(status_code=404, detail="Labour not found")
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.delete("/{labour_id}")
def deactivate_labour(labour_id: int, db: Session = Depends(get_db)):
    """Deactivate labour - business logic from service"""
    result = LabourService.deactivate_labour(db, labour_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Labour not found")
    return {"message": f"Labour {labour_id} deactivated successfully"}