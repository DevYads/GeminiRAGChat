from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from db.session import get_db
from schemas import Contractor, ContractorCreate, ContractorUpdate
from crud import contractor

router = APIRouter(prefix="/contractors", tags=["contractors"])

@router.get("/", response_model=List[Contractor])
def read_contractors(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return contractor.get_multi(db, skip=skip, limit=limit)

@router.post("/", response_model=Contractor)
def create_contractor(contractor_in: ContractorCreate, db: Session = Depends(get_db)):
    return contractor.create(db, obj_in=contractor_in)

@router.get("/{contractor_id}", response_model=Contractor)
def read_contractor(contractor_id: int, db: Session = Depends(get_db)):
    db_contractor = contractor.get(db, id=contractor_id)
    if db_contractor is None:
        raise HTTPException(status_code=404, detail="Contractor not found")
    return db_contractor