from typing import List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from datetime import date

from db.session import get_db
from schemas import AttendanceSummary, AttendanceSummaryCreate
from services.attendance_service import AttendanceService

router = APIRouter(prefix="/attendance", tags=["attendance"])

@router.post("/import-summary")
def import_attendance_from_mssql(
    target_date: date = Query(..., description="Date to import (YYYY-MM-DD)"),
    db: Session = Depends(get_db)
):
    """Import attendance from MS SQL punch data - business logic from service"""
    try:
        result = AttendanceService.import_attendance_from_mssql(db, target_date)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Import failed: {str(e)}")

@router.get("/{labour_id}")
def get_labour_attendance_calendar(
    labour_id: int,
    month: int = Query(..., description="Month (1-12)"),
    year: int = Query(..., description="Year"),
    db: Session = Depends(get_db)
):
    """Get attendance calendar with business calculations - service layer"""
    try:
        result = AttendanceService.get_labour_attendance_calendar(db, labour_id, month, year)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{labour_id}/records", response_model=List[AttendanceSummary])
def get_labour_attendance_records(
    labour_id: int,
    month: int = Query(..., description="Month (1-12)"),
    year: int = Query(..., description="Year"),
    db: Session = Depends(get_db)
):
    """Get raw attendance records for labour"""
    result = AttendanceService.get_labour_attendance_calendar(db, labour_id, month, year)
    return result["attendance_records"]

@router.post("/", response_model=AttendanceSummary)
def create_manual_attendance_record(attendance_in: AttendanceSummaryCreate, db: Session = Depends(get_db)):
    """Create manual attendance record - business logic from service"""
    try:
        return AttendanceService.create_manual_attendance(db, attendance_in)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))