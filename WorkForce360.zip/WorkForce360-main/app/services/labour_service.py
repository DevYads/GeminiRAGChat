from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from crud import labour, plant, department, contractor, grade, ppe_rate
from schemas.labours import CasualLabour, CasualLabourCreate, CasualLabourUpdate

class LabourService:
    """Business logic for Labour operations"""
    
    @staticmethod
    def create_labour(db: Session, labour_data: CasualLabourCreate) -> CasualLabour:
        """Create new labour with business validations"""
        # Business rule: Check if employee ID already exists
        existing_labour = labour.get_by_emp_id(db, emp_id=labour_data.emp_id)
        if existing_labour:
            raise ValueError(f"Employee with ID '{labour_data.emp_id}' already exists")
        
        # Business rule: Validate referenced entities exist
        if not plant.get(db, id=labour_data.plant_id):
            raise ValueError(f"Plant with ID {labour_data.plant_id} does not exist")
        
        if not department.get(db, id=labour_data.department_id):
            raise ValueError(f"Department with ID {labour_data.department_id} does not exist")
        
        if not contractor.get(db, id=labour_data.contractor_id):
            raise ValueError(f"Contractor with ID {labour_data.contractor_id} does not exist")
        
        if not grade.get(db, id=labour_data.grade_id):
            raise ValueError(f"Grade with ID {labour_data.grade_id} does not exist")
        
        # Business rule: Validate PPE code if provided
        if labour_data.ppe_code:
            ppe_obj = ppe_rate.get_by_code(db, code=labour_data.ppe_code)
            if not ppe_obj:
                raise ValueError(f"PPE code '{labour_data.ppe_code}' does not exist")
            if not ppe_obj.active_status:
                raise ValueError(f"PPE code '{labour_data.ppe_code}' is inactive")
        
        # Business rule: Validate Aadhar format if provided
        if labour_data.aadhar and len(labour_data.aadhar) != 12:
            raise ValueError("Aadhar number must be 12 digits")
        
        return labour.create(db, obj_in=labour_data)
    
    @staticmethod
    def get_labour_by_id(db: Session, labour_id: int) -> Optional[CasualLabour]:
        """Get labour by ID"""
        return labour.get(db, id=labour_id)
    
    @staticmethod
    def get_labours_by_filters(db: Session, filters: Dict[str, Any], skip: int = 0, limit: int = 100) -> List[CasualLabour]:
        """Get labours with business logic filtering"""
        # Business rule: Only return active labours by default
        if 'active_status' not in filters:
            filters['active_status'] = True
        
        return labour.get_multi_filtered(db, filters=filters, skip=skip, limit=limit)
    
    @staticmethod
    def get_labour_details(db: Session, labour_id: int) -> Optional[Dict[str, Any]]:
        """Get complete labour details with related entities"""
        labour_obj = labour.get(db, id=labour_id)
        if not labour_obj:
            return None
        
        # Get related entities
        plant_obj = plant.get(db, id=labour_obj.plant_id)
        dept_obj = department.get(db, id=labour_obj.department_id)
        contractor_obj = contractor.get(db, id=labour_obj.contractor_id)
        grade_obj = grade.get(db, id=labour_obj.grade_id)
        ppe_obj = None
        if labour_obj.ppe_code:
            ppe_obj = ppe_rate.get_by_code(db, code=labour_obj.ppe_code)
        
        return {
            "labour": labour_obj,
            "plant": plant_obj,
            "department": dept_obj,
            "contractor": contractor_obj,
            "grade": grade_obj,
            "ppe_rate": ppe_obj
        }
    
    @staticmethod
    def update_labour(db: Session, labour_id: int, labour_data: CasualLabourUpdate) -> Optional[CasualLabour]:
        """Update labour with business rules"""
        labour_obj = labour.get(db, id=labour_id)
        if not labour_obj:
            return None
        
        # Business rule: If updating emp_id, ensure it's unique
        if labour_data.emp_id and labour_data.emp_id != labour_obj.emp_id:
            existing_labour = labour.get_by_emp_id(db, emp_id=labour_data.emp_id)
            if existing_labour:
                raise ValueError(f"Employee with ID '{labour_data.emp_id}' already exists")
        
        return labour.update(db, db_obj=labour_obj, obj_in=labour_data)
    
    @staticmethod
    def deactivate_labour(db: Session, labour_id: int) -> Optional[CasualLabour]:
        """Deactivate labour instead of deleting"""
        labour_obj = labour.get(db, id=labour_id)
        if not labour_obj:
            return None
        
        # Business rule: Deactivate instead of delete
        labour_update = CasualLabourUpdate(active_status=False)
        return labour.update(db, db_obj=labour_obj, obj_in=labour_update)