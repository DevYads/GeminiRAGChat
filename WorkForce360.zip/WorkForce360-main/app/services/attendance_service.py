from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from datetime import date, datetime, timedelta
from decimal import Decimal

from db.attendance_session import get_attendance_db, AttendancePunch
from crud import attendance, labour
from schemas.attendance import AttendanceSummary, AttendanceSummaryCreate

class AttendanceService:
    """Business logic for Attendance operations including MS SQL integration"""
    
    @staticmethod
    def import_attendance_from_mssql(db: Session, target_date: date) -> Dict[str, Any]:
        """Import attendance from MS SQL punch data for a specific date"""
        attendance_db = next(get_attendance_db())
        
        try:
            # Get all punch records for the target date
            date_str = target_date.strftime('%Y-%m-%d')
            punches = attendance_db.query(AttendancePunch).filter(
                AttendancePunch.punch_date == date_str
            ).order_by(AttendancePunch.emp_id, AttendancePunch.punch_time).all()
            
            # Group punches by employee
            employee_punches = {}
            for punch in punches:
                if punch.emp_id not in employee_punches:
                    employee_punches[punch.emp_id] = []
                employee_punches[punch.emp_id].append(punch)
            
            imported_count = 0
            errors = []
            
            for emp_id, emp_punches in employee_punches.items():
                try:
                    # Get labour record
                    labour_obj = labour.get_by_emp_id(db, emp_id=emp_id)
                    if not labour_obj:
                        errors.append(f"Employee {emp_id} not found in system")
                        continue
                    
                    # Check if attendance already exists for this date
                    existing_attendance = attendance.get_by_labour_and_date_range(
                        db, labour_id=labour_obj.id, 
                        start_date=target_date, end_date=target_date
                    )
                    if existing_attendance:
                        continue  # Skip if already imported
                    
                    # Business logic: Calculate attendance from punches
                    attendance_data = AttendanceService._calculate_attendance_from_punches(
                        emp_punches, labour_obj.id, target_date
                    )
                    
                    # Create attendance record
                    attendance.create(db, obj_in=attendance_data)
                    imported_count += 1
                    
                except Exception as e:
                    errors.append(f"Error processing {emp_id}: {str(e)}")
            
            return {
                "date": target_date.isoformat(),
                "imported_count": imported_count,
                "errors": errors,
                "total_employees_processed": len(employee_punches)
            }
            
        finally:
            attendance_db.close()
    
    @staticmethod
    def _calculate_attendance_from_punches(punches: List[AttendancePunch], labour_id: int, target_date: date) -> AttendanceSummaryCreate:
        """Business logic: Calculate daily attendance from punch records"""
        if not punches:
            return AttendanceSummaryCreate(
                labour_id=labour_id,
                date=target_date,
                shift_type="8Hr",
                hours_worked=Decimal('0'),
                is_present=False,
                is_holiday=False,
                overtime_hours=Decimal('0')
            )
        
        # Sort punches by time
        punches.sort(key=lambda x: x.punch_time)
        
        # Business rule: Find first IN and last OUT
        in_punches = [p for p in punches if p.punch_type == 'IN']
        out_punches = [p for p in punches if p.punch_type == 'OUT']
        
        if not in_punches or not out_punches:
            # If only IN or only OUT punches, consider present but 0 hours
            return AttendanceSummaryCreate(
                labour_id=labour_id,
                date=target_date,
                shift_type="8Hr",
                hours_worked=Decimal('0'),
                is_present=True,
                is_holiday=False,
                overtime_hours=Decimal('0'),
                remarks="Incomplete punch data"
            )
        
        first_in = in_punches[0].punch_time
        last_out = out_punches[-1].punch_time
        
        # Calculate total hours
        total_time = last_out - first_in
        total_hours = Decimal(str(total_time.total_seconds() / 3600))
        
        # Business rule: Determine shift type and overtime
        if total_hours <= Decimal('8'):
            shift_type = "8Hr"
            regular_hours = total_hours
            overtime_hours = Decimal('0')
        elif total_hours <= Decimal('12'):
            shift_type = "12Hr"
            regular_hours = total_hours
            overtime_hours = Decimal('0')
        else:
            # More than 12 hours - consider as overtime
            shift_type = "12Hr"
            regular_hours = Decimal('12')
            overtime_hours = total_hours - Decimal('12')
        
        # Business rule: Check if it's a holiday (simplified - you can add holiday logic)
        is_holiday = target_date.weekday() == 6  # Sunday
        
        return AttendanceSummaryCreate(
            labour_id=labour_id,
            date=target_date,
            shift_type=shift_type,
            hours_worked=regular_hours,
            is_present=True,
            is_holiday=is_holiday,
            overtime_hours=overtime_hours,
            remarks=f"Imported from punch data: {len(punches)} punches"
        )
    
    @staticmethod
    def get_labour_attendance_calendar(db: Session, labour_id: int, month: int, year: int) -> Dict[str, Any]:
        """Get attendance calendar with business calculations"""
        # Get attendance records
        attendance_records = attendance.get_by_month_year(db, labour_id=labour_id, month=month, year=year)
        
        # Business calculations
        total_days = len(attendance_records)
        present_days = sum(1 for record in attendance_records if record.is_present)
        absent_days = total_days - present_days
        total_hours = sum(record.hours_worked or Decimal('0') for record in attendance_records)
        overtime_hours = sum(record.overtime_hours or Decimal('0') for record in attendance_records)
        holiday_days = sum(1 for record in attendance_records if record.is_holiday)
        
        return {
            "labour_id": labour_id,
            "month": month,
            "year": year,
            "attendance_records": attendance_records,
            "summary": {
                "total_days": total_days,
                "present_days": present_days,
                "absent_days": absent_days,
                "total_hours": float(total_hours),
                "overtime_hours": float(overtime_hours),
                "holiday_days": holiday_days,
                "attendance_percentage": round((present_days / total_days * 100) if total_days > 0 else 0, 2)
            }
        }
    
    @staticmethod
    def create_manual_attendance(db: Session, attendance_data: AttendanceSummaryCreate) -> AttendanceSummary:
        """Create manual attendance record with business validation"""
        # Business rule: Validate labour exists
        labour_obj = labour.get(db, id=attendance_data.labour_id)
        if not labour_obj:
            raise ValueError(f"Labour with ID {attendance_data.labour_id} not found")
        
        # Business rule: Check for duplicate attendance
        existing_attendance = attendance.get_by_labour_and_date_range(
            db, labour_id=attendance_data.labour_id,
            start_date=attendance_data.date, end_date=attendance_data.date
        )
        if existing_attendance:
            raise ValueError(f"Attendance already exists for {attendance_data.date}")
        
        # Business rule: Validate hours
        if attendance_data.hours_worked and attendance_data.hours_worked < 0:
            raise ValueError("Hours worked cannot be negative")
        
        if attendance_data.overtime_hours and attendance_data.overtime_hours < 0:
            raise ValueError("Overtime hours cannot be negative")
        
        return attendance.create(db, obj_in=attendance_data)