from typing import List, Optional
from sqlalchemy.orm import Session

from crud import plant, department
from schemas.plants import Plant, PlantCreate, PlantUpdate
from schemas.departments import Department

class PlantService:
    """Business logic for Plant operations"""
    
    @staticmethod
    def create_plant(db: Session, plant_data: PlantCreate) -> Plant:
        """Create new plant with business rules"""
        # Business rule: Check if plant code already exists
        existing_plant = plant.get_by_code(db, code=plant_data.code)
        if existing_plant:
            raise ValueError(f"Plant with code '{plant_data.code}' already exists")
        
        # Business rule: Validate plant code format (uppercase, alphanumeric)
        if not plant_data.code.isalnum() or not plant_data.code.isupper():
            raise ValueError("Plant code must be uppercase alphanumeric")
        
        return plant.create(db, obj_in=plant_data)
    
    @staticmethod
    def get_plant_by_id(db: Session, plant_id: int) -> Optional[Plant]:
        """Get plant by ID"""
        return plant.get(db, id=plant_id)
    
    @staticmethod
    def get_all_plants(db: Session, skip: int = 0, limit: int = 100) -> List[Plant]:
        """Get all plants with pagination"""
        return plant.get_multi(db, skip=skip, limit=limit)
    
    @staticmethod
    def get_plant_with_departments(db: Session, plant_id: int) -> dict:
        """Get plant with all its departments - business logic"""
        plant_obj = plant.get(db, id=plant_id)
        if not plant_obj:
            return None
        
        departments = department.get_by_plant(db, plant_id=plant_id)
        
        return {
            "plant": plant_obj,
            "departments": departments,
            "department_count": len(departments)
        }
    
    @staticmethod
    def update_plant(db: Session, plant_id: int, plant_data: PlantUpdate) -> Optional[Plant]:
        """Update plant with business rules"""
        plant_obj = plant.get(db, id=plant_id)
        if not plant_obj:
            return None
        
        # Business rule: If updating code, ensure it's unique
        if plant_data.code and plant_data.code != plant_obj.code:
            existing_plant = plant.get_by_code(db, code=plant_data.code)
            if existing_plant:
                raise ValueError(f"Plant with code '{plant_data.code}' already exists")
        
        return plant.update(db, db_obj=plant_obj, obj_in=plant_data)