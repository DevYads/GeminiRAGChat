from typing import Dict, List, Optional, Any
from sqlalchemy.orm import Session
from decimal import Decimal
from calendar import monthrange

from crud import labour, attendance, payroll, grade, ppe_rate
from schemas.payroll import PayrollRecordCreate, PayrollRecord

class EnhancedPayrollService:
    """Enhanced business logic for Payroll operations with complete calculations"""
    
    @staticmethod
    def calculate_labour_payroll(db: Session, labour_id: int, month: int, year: int) -> Optional[Dict[str, Any]]:
        """Calculate complete payroll for a labour with all business rules"""
        
        # Get labour details
        labour_obj = labour.get(db, id=labour_id)
        if not labour_obj:
            raise ValueError(f"Labour with ID {labour_id} not found")
        
        # Get grade and PPE rate details
        grade_obj = grade.get(db, id=labour_obj.grade_id)
        if not grade_obj:
            raise ValueError(f"Grade not found for labour {labour_id}")
        
        ppe_obj = None
        if labour_obj.ppe_code:
            ppe_obj = ppe_rate.get_by_code(db, code=labour_obj.ppe_code)
            if not ppe_obj or not ppe_obj.active_status:
                raise ValueError(f"Invalid or inactive PPE code: {labour_obj.ppe_code}")
        
        # Get attendance records for the month
        attendance_records = attendance.get_by_month_year(db, labour_id=labour_id, month=month, year=year)
        
        # Business Rule: Calculate attendance totals
        total_days_worked = sum(1 for record in attendance_records if record.is_present)
        total_hours = sum(record.hours_worked or Decimal('0') for record in attendance_records)
        overtime_hours = sum(record.overtime_hours or Decimal('0') for record in attendance_records)
        holiday_days_worked = sum(1 for record in attendance_records if record.is_holiday and record.is_present)
        
        # Business Rule: Calculate gross amounts
        regular_amount = total_hours * grade_obj.base_rate
        overtime_amount = overtime_hours * grade_obj.overtime_rate
        gross_amount = regular_amount + overtime_amount
        
        # Business Rule: PF Calculation
        pf_amount = Decimal('0')
        pf_days = 0
        if grade_obj.pf_applicable and grade_obj.pf_percent and total_days_worked > 0:
            pf_days = total_days_worked
            # PF is calculated on gross amount but capped at statutory limit
            pf_eligible_amount = min(gross_amount, Decimal('15000'))  # Statutory PF ceiling
            pf_amount = pf_eligible_amount * (grade_obj.pf_percent / 100)
        
        # Business Rule: ESIC Calculation  
        esic_amount = Decimal('0')
        if grade_obj.esic_applicable and grade_obj.esic_percent and total_days_worked > 0:
            # ESIC is calculated on gross amount but capped at statutory limit
            esic_eligible_amount = min(gross_amount, Decimal('25000'))  # Statutory ESIC ceiling
            esic_amount = esic_eligible_amount * (grade_obj.esic_percent / 100)
        
        # Business Rule: Bonus Calculation
        bonus_amount = Decimal('0')
        bonus_days = 0
        if grade_obj.bonus_applicable and grade_obj.bonus_percent and total_days_worked > 0:
            # Bonus is typically calculated on basic salary component
            basic_component = gross_amount * Decimal('0.6')  # Assume 60% is basic
            bonus_days = total_days_worked
            bonus_amount = basic_component * (grade_obj.bonus_percent / 100)
        
        # Business Rule: Attendance Incentive
        attendance_incentive = Decimal('0')
        if grade_obj.attendance_incentive_rate and total_days_worked > 0:
            # Full month attendance gets full incentive
            _, month_days = monthrange(year, month)
            working_days = month_days - 4  # Assume 4 Sundays
            
            if total_days_worked >= working_days:
                attendance_incentive = grade_obj.attendance_incentive_rate * total_days_worked
            elif total_days_worked >= (working_days * 0.9):  # 90% attendance
                attendance_incentive = grade_obj.attendance_incentive_rate * total_days_worked * Decimal('0.8')
        
        # Business Rule: PPE Amount
        ppe_amount = Decimal('0')
        ppe_rate_value = Decimal('0')
        if ppe_obj and total_days_worked > 0:
            ppe_rate_value = ppe_obj.rate
            ppe_amount = total_days_worked * ppe_obj.rate
        
        # Business Rule: Additional allowances from grade
        other_allowances_amount = Decimal('0')
        if grade_obj.other_allowances and total_days_worked > 0:
            for allowance, rate in grade_obj.other_allowances.items():
                if isinstance(rate, (int, float)):
                    other_allowances_amount += Decimal(str(rate)) * total_days_worked
        
        # Business Rule: Deductions (simplified - can be enhanced)
        canteen_deduction = total_days_worked * Decimal('50')  # ₹50 per day
        bus_deduction = total_days_worked * Decimal('30')     # ₹30 per day
        
        # Business Rule: Holiday pay (if applicable)
        holiday_pay = Decimal('0')
        if holiday_days_worked > 0:
            holiday_pay = holiday_days_worked * grade_obj.base_rate * Decimal('8')  # 8 hours per holiday
        
        # Calculate total earnings and deductions
        total_earnings = (gross_amount + bonus_amount + attendance_incentive + 
                         ppe_amount + other_allowances_amount + holiday_pay)
        total_deductions = pf_amount + esic_amount + canteen_deduction + bus_deduction
        net_pay = total_earnings - total_deductions
        
        return {
            "labour_id": labour_id,
            "month": month,
            "year": year,
            "labour_details": {
                "emp_id": labour_obj.emp_id,
                "name": labour_obj.name,
                "grade_code": grade_obj.code,
                "ppe_code": labour_obj.ppe_code
            },
            "attendance_summary": {
                "total_days_worked": total_days_worked,
                "total_hours": float(total_hours),
                "overtime_hours": float(overtime_hours),
                "holiday_days_worked": holiday_days_worked
            },
            "earnings": {
                "regular_amount": float(regular_amount),
                "overtime_amount": float(overtime_amount),
                "gross_amount": float(gross_amount),
                "bonus_amount": float(bonus_amount),
                "attendance_incentive": float(attendance_incentive),
                "ppe_amount": float(ppe_amount),
                "other_allowances": float(other_allowances_amount),
                "holiday_pay": float(holiday_pay),
                "total_earnings": float(total_earnings)
            },
            "deductions": {
                "pf_amount": float(pf_amount),
                "esic_amount": float(esic_amount),
                "canteen_deduction": float(canteen_deduction),
                "bus_deduction": float(bus_deduction),
                "total_deductions": float(total_deductions)
            },
            "payroll_record": {
                "total_days_worked": total_days_worked,
                "total_hours": float(total_hours),
                "rate": float(grade_obj.base_rate),
                "gross_amount": float(gross_amount),
                "pf_days": pf_days,
                "pf_amount": float(pf_amount),
                "esic_amount": float(esic_amount),
                "bonus_days": bonus_days,
                "bonus_amount": float(bonus_amount),
                "attendance_incentive": float(attendance_incentive),
                "ppe_rate": float(ppe_rate_value),
                "ppe_amount": float(ppe_amount),
                "canteen_deduction": float(canteen_deduction),
                "bus_deduction": float(bus_deduction),
                "net_pay": float(net_pay)
            }
        }
    
    @staticmethod
    def generate_payroll_for_period(db: Session, month: int, year: int, plant_id: Optional[int] = None) -> Dict[str, Any]:
        """Generate payroll for all active labours in given period with business rules"""
        
        # Get active labours based on plant filter
        filters = {"active_status": True}
        if plant_id:
            filters["plant_id"] = plant_id
        
        active_labours = labour.get_multi_filtered(db, filters=filters)
        
        generated_count = 0
        skipped_count = 0
        errors = []
        
        for labour_obj in active_labours:
            try:
                # Business Rule: Check if payroll already exists
                existing_payroll = payroll.get_by_labour_and_period(
                    db, labour_id=labour_obj.id, month=month, year=year
                )
                if existing_payroll:
                    skipped_count += 1
                    continue
                
                # Calculate payroll
                payroll_calculation = EnhancedPayrollService.calculate_labour_payroll(
                    db, labour_obj.id, month, year
                )
                
                if payroll_calculation:
                    # Create payroll record with snapshot values
                    payroll_data = PayrollRecordCreate(
                        labour_id=labour_obj.id,
                        month=month,
                        year=year,
                        **payroll_calculation["payroll_record"]
                    )
                    payroll.create(db, obj_in=payroll_data)
                    generated_count += 1
                
            except Exception as e:
                errors.append(f"Error processing labour {labour_obj.emp_id}: {str(e)}")
        
        return {
            "month": month,
            "year": year,
            "plant_id": plant_id,
            "total_labours": len(active_labours),
            "generated_count": generated_count,
            "skipped_count": skipped_count,
            "errors": errors,
            "success": len(errors) == 0
        }
    
    @staticmethod
    def get_labour_payroll_details(db: Session, labour_id: int, month: int, year: int) -> Optional[Dict[str, Any]]:
        """Get detailed payroll information for a labour"""
        payroll_record = payroll.get_by_labour_and_period(db, labour_id=labour_id, month=month, year=year)
        
        if not payroll_record:
            return None
        
        # Get labour details for context
        labour_obj = labour.get(db, id=labour_id)
        grade_obj = grade.get(db, id=labour_obj.grade_id) if labour_obj else None
        
        return {
            "payroll_record": payroll_record,
            "labour": labour_obj,
            "grade": grade_obj,
            "summary": {
                "gross_earnings": float(payroll_record.gross_amount + payroll_record.bonus_amount + 
                                      payroll_record.attendance_incentive + payroll_record.ppe_amount),
                "total_deductions": float(payroll_record.pf_amount + payroll_record.esic_amount + 
                                        payroll_record.canteen_deduction + payroll_record.bus_deduction),
                "net_payable": float(payroll_record.net_pay)
            }
        }
    
    @staticmethod
    def get_payroll_summary_by_period(db: Session, month: int, year: int, plant_id: Optional[int] = None) -> Dict[str, Any]:
        """Get payroll summary for a period with business analytics"""
        payroll_records = payroll.get_by_period(db, month=month, year=year)
        
        # Filter by plant if specified
        if plant_id:
            filtered_records = []
            for record in payroll_records:
                labour_obj = labour.get(db, id=record.labour_id)
                if labour_obj and labour_obj.plant_id == plant_id:
                    filtered_records.append(record)
            payroll_records = filtered_records
        
        if not payroll_records:
            return {
                "month": month,
                "year": year,
                "plant_id": plant_id,
                "total_records": 0,
                "summary": {}
            }
        
        # Calculate summary statistics
        total_gross = sum(record.gross_amount for record in payroll_records)
        total_pf = sum(record.pf_amount for record in payroll_records)
        total_esic = sum(record.esic_amount for record in payroll_records)
        total_bonus = sum(record.bonus_amount for record in payroll_records)
        total_net = sum(record.net_pay for record in payroll_records)
        total_days_worked = sum(record.total_days_worked for record in payroll_records)
        total_hours = sum(record.total_hours for record in payroll_records)
        
        return {
            "month": month,
            "year": year,
            "plant_id": plant_id,
            "total_records": len(payroll_records),
            "summary": {
                "total_gross_amount": float(total_gross),
                "total_pf_amount": float(total_pf),
                "total_esic_amount": float(total_esic),
                "total_bonus_amount": float(total_bonus),
                "total_net_pay": float(total_net),
                "total_days_worked": total_days_worked,
                "total_hours_worked": float(total_hours),
                "average_net_pay": float(total_net / len(payroll_records)),
                "average_days_worked": round(total_days_worked / len(payroll_records), 2)
            },
            "records": payroll_records
        }