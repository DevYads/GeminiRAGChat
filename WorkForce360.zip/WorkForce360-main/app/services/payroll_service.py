from sqlalchemy.orm import Session
from decimal import Decimal
from calendar import monthrange

from crud import labour, attendance, payroll, grade, ppe_rate
from schemas.payroll import PayrollRecordCreate

def calculate_payroll_for_labour(db: Session, labour_id: int, month: int, year: int) -> dict:
    """Calculate payroll for a single labour for given month/year"""
    
    # Get labour details
    labour_record = labour.get(db, id=labour_id)
    if not labour_record:
        return None
    
    # Get grade and PPE rate details
    grade_record = grade.get(db, id=labour_record.grade_id)
    ppe_record = None
    if labour_record.ppe_code:
        ppe_record = ppe_rate.get_by_code(db, code=labour_record.ppe_code)
    
    # Get attendance records for the month
    attendance_records = attendance.get_by_month_year(db, labour_id=labour_id, month=month, year=year)
    
    # Calculate totals
    total_days_worked = sum(1 for record in attendance_records if record.is_present)
    total_hours = sum(record.hours_worked or Decimal('0') for record in attendance_records)
    overtime_hours = sum(record.overtime_hours or Decimal('0') for record in attendance_records)
    
    # Calculate amounts
    regular_amount = total_hours * grade_record.base_rate
    overtime_amount = overtime_hours * grade_record.overtime_rate
    gross_amount = regular_amount + overtime_amount
    
    # PF calculation
    pf_amount = Decimal('0')
    pf_days = 0
    if grade_record.pf_applicable and grade_record.pf_percent:
        pf_days = total_days_worked
        pf_amount = gross_amount * (grade_record.pf_percent / 100)
    
    # ESIC calculation
    esic_amount = Decimal('0')
    if grade_record.esic_applicable and grade_record.esic_percent:
        esic_amount = gross_amount * (grade_record.esic_percent / 100)
    
    # Bonus calculation
    bonus_amount = Decimal('0')
    bonus_days = 0
    if grade_record.bonus_applicable and grade_record.bonus_percent:
        bonus_days = total_days_worked
        bonus_amount = gross_amount * (grade_record.bonus_percent / 100)
    
    # Attendance incentive
    attendance_incentive = Decimal('0')
    if grade_record.attendance_incentive_rate:
        attendance_incentive = total_days_worked * grade_record.attendance_incentive_rate
    
    # PPE amount
    ppe_amount = Decimal('0')
    ppe_rate_value = Decimal('0')
    if ppe_record:
        ppe_rate_value = ppe_record.rate
        ppe_amount = total_days_worked * ppe_record.rate
    
    # Calculate net pay (simplified - can add more deductions)
    net_pay = gross_amount + bonus_amount + attendance_incentive + ppe_amount - pf_amount - esic_amount
    
    return {
        "labour_id": labour_id,
        "month": month,
        "year": year,
        "total_days_worked": total_days_worked,
        "total_hours": float(total_hours),
        "rate": float(grade_record.base_rate),
        "gross_amount": float(gross_amount),
        "pf_days": pf_days,
        "pf_amount": float(pf_amount),
        "esic_amount": float(esic_amount),
        "bonus_days": bonus_days,
        "bonus_amount": float(bonus_amount),
        "attendance_incentive": float(attendance_incentive),
        "ppe_rate": float(ppe_rate_value),
        "ppe_amount": float(ppe_amount),
        "canteen_deduction": 0.0,
        "bus_deduction": 0.0,
        "net_pay": float(net_pay)
    }

def generate_payroll_for_period(db: Session, month: int, year: int, plant_id: int = None):
    """Generate payroll for all active labours in given period"""
    
    # Get all active labours (optionally filtered by plant)
    if plant_id:
        labours = labour.get_by_plant_and_contractor(db, plant_id=plant_id, contractor_id=None)
    else:
        labours = labour.get_active(db)
    
    generated_count = 0
    for labour_record in labours:
        # Check if payroll already exists
        existing_payroll = payroll.get_by_labour_and_period(
            db, labour_id=labour_record.id, month=month, year=year
        )
        if existing_payroll:
            continue  # Skip if already generated
        
        # Calculate payroll
        payroll_data = calculate_payroll_for_labour(db, labour_record.id, month, year)
        if payroll_data:
            # Create payroll record
            payroll_create = PayrollRecordCreate(**payroll_data)
            payroll.create(db, obj_in=payroll_create)
            generated_count += 1
    
    return {"generated_count": generated_count}