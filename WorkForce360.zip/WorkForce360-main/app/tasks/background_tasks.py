from celery import Celery
from sqlalchemy.orm import Session

from db.session import SessionLocal
from services.payroll_service import generate_payroll_for_period

# Initialize Celery
celery_app = Celery("workforce360")
celery_app.config_from_object({
    'broker_url': 'redis://localhost:6379/0',
    'result_backend': 'redis://localhost:6379/0',
    'task_serializer': 'json',
    'accept_content': ['json'],
    'result_serializer': 'json',
    'timezone': 'UTC',
    'enable_utc': True,
})

@celery_app.task
def generate_payroll_task(month: int, year: int, plant_id: int = None):
    """Background task for payroll generation"""
    db = SessionLocal()
    try:
        result = generate_payroll_for_period(db, month, year, plant_id)
        return result
    finally:
        db.close()

@celery_app.task
def bulk_import_attendance_task(attendance_data: list):
    """Background task for bulk attendance import"""
    db = SessionLocal()
    try:
        # Import logic here
        return {"imported_count": len(attendance_data)}
    finally:
        db.close()