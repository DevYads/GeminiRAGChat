from pydantic import BaseModel, Field
from typing import Optional
from decimal import Decimal
from datetime import datetime

class PayrollRecordBase(BaseModel):
    labour_id: int = Field(..., description="Labour ID")
    month: int = Field(..., description="Month")
    year: int = Field(..., description="Year")
    total_days_worked: int = Field(0, description="Total days worked")
    total_hours: Decimal = Field(Decimal('0'), description="Total hours")
    rate: Optional[Decimal] = Field(None, description="Hourly rate")
    gross_amount: Decimal = Field(Decimal('0'), description="Gross amount")
    pf_days: int = Field(0, description="PF applicable days")
    pf_amount: Decimal = Field(Decimal('0'), description="PF amount")
    esic_amount: Decimal = Field(Decimal('0'), description="ESIC amount")
    bonus_days: int = Field(0, description="Bonus applicable days")
    bonus_amount: Decimal = Field(Decimal('0'), description="Bonus amount")
    attendance_incentive: Decimal = Field(Decimal('0'), description="Attendance incentive")
    ppe_rate: Decimal = Field(Decimal('0'), description="PPE rate")
    ppe_amount: Decimal = Field(Decimal('0'), description="PPE amount")
    canteen_deduction: Decimal = Field(Decimal('0'), description="Canteen deduction")
    bus_deduction: Decimal = Field(Decimal('0'), description="Bus deduction")
    net_pay: Decimal = Field(Decimal('0'), description="Net pay")

class PayrollRecordCreate(PayrollRecordBase):
    pass

class PayrollRecord(PayrollRecordBase):
    id: int
    generated_at: datetime

    class Config:
        from_attributes = True

class PayrollGenerate(BaseModel):
    month: int = Field(..., description="Month to generate payroll")
    year: int = Field(..., description="Year to generate payroll")
    plant_id: Optional[int] = Field(None, description="Plant ID filter")