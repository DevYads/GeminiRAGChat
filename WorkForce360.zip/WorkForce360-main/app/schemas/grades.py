from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
from decimal import Decimal
from datetime import datetime

class CasualGradeBase(BaseModel):
    code: str = Field(..., description="Unique grade code")
    description: Optional[str] = Field(None, description="Grade description")
    base_rate: Decimal = Field(..., description="Base hourly rate")
    overtime_rate: Decimal = Field(..., description="Overtime hourly rate")
    pf_applicable: bool = Field(False, description="PF applicable")
    pf_percent: Optional[Decimal] = Field(None, description="PF percentage")
    esic_applicable: bool = Field(False, description="ESIC applicable")
    esic_percent: Optional[Decimal] = Field(None, description="ESIC percentage")
    bonus_applicable: bool = Field(False, description="Bonus applicable")
    bonus_percent: Optional[Decimal] = Field(None, description="Bonus percentage")
    attendance_incentive_rate: Optional[Decimal] = Field(None, description="Attendance incentive rate")
    other_allowances: Optional[Dict[str, Any]] = Field(None, description="Other allowances")

class CasualGradeCreate(CasualGradeBase):
    pass

class CasualGradeUpdate(BaseModel):
    code: Optional[str] = None
    description: Optional[str] = None
    base_rate: Optional[Decimal] = None
    overtime_rate: Optional[Decimal] = None
    pf_applicable: Optional[bool] = None
    pf_percent: Optional[Decimal] = None
    esic_applicable: Optional[bool] = None
    esic_percent: Optional[Decimal] = None
    bonus_applicable: Optional[bool] = None
    bonus_percent: Optional[Decimal] = None
    attendance_incentive_rate: Optional[Decimal] = None
    other_allowances: Optional[Dict[str, Any]] = None

class CasualGrade(CasualGradeBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True