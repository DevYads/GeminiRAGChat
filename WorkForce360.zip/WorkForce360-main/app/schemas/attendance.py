from pydantic import BaseModel, Field
from typing import Optional, List
from decimal import Decimal
from datetime import date as DateType, datetime

class AttendanceSummaryBase(BaseModel):
    labour_id: int = Field(..., description="Labour ID")
    date: DateType = Field(..., description="Attendance date")
    shift_type: str = Field(..., description="Shift type (8Hr/12Hr)")
    hours_worked: Optional[Decimal] = Field(None, description="Hours worked")
    is_present: bool = Field(False, description="Present status")
    is_holiday: bool = Field(False, description="Holiday status")
    overtime_hours: Decimal = Field(Decimal('0'), description="Overtime hours")
    remarks: Optional[str] = Field(None, description="Remarks")

class AttendanceSummaryCreate(AttendanceSummaryBase):
    pass

class AttendanceSummaryUpdate(BaseModel):
    shift_type: Optional[str] = None
    hours_worked: Optional[Decimal] = None
    is_present: Optional[bool] = None
    is_holiday: Optional[bool] = None
    overtime_hours: Optional[Decimal] = None
    remarks: Optional[str] = None

class AttendanceSummary(AttendanceSummaryBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

class AttendanceBulkImport(BaseModel):
    attendance_records: List[AttendanceSummaryCreate] = Field(..., description="List of attendance records")