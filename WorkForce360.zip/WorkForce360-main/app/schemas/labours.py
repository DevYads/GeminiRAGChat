from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class CasualLabourBase(BaseModel):
    emp_id: str = Field(..., description="Employee ID")
    contractor_id: int = Field(..., description="Contractor ID")
    plant_id: int = Field(..., description="Plant ID")
    department_id: int = Field(..., description="Department ID")
    grade_id: int = Field(..., description="Grade ID")
    ppe_code: Optional[str] = Field(None, description="PPE code")
    name: str = Field(..., description="Employee name")
    gender: Optional[str] = Field(None, description="Gender")
    aadhar: Optional[str] = Field(None, description="Aadhar number")
    active_status: bool = Field(True, description="Active status")

class CasualLabourCreate(CasualLabourBase):
    pass

class CasualLabourUpdate(BaseModel):
    emp_id: Optional[str] = None
    contractor_id: Optional[int] = None
    plant_id: Optional[int] = None
    department_id: Optional[int] = None
    grade_id: Optional[int] = None
    ppe_code: Optional[str] = None
    name: Optional[str] = None
    gender: Optional[str] = None
    aadhar: Optional[str] = None
    active_status: Optional[bool] = None

class CasualLabour(CasualLabourBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True