from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class PlantBase(BaseModel):
    name: str = Field(..., description="Plant name")
    location: Optional[str] = Field(None, description="Plant location")
    code: str = Field(..., description="Unique plant code")

class PlantCreate(PlantBase):
    pass

class PlantUpdate(BaseModel):
    name: Optional[str] = None
    location: Optional[str] = None
    code: Optional[str] = None

class Plant(PlantBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True