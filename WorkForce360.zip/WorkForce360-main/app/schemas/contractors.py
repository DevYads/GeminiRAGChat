from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
from datetime import datetime

class ContractorBase(BaseModel):
    name: str = Field(..., description="Contractor name")
    branch: Optional[str] = Field(None, description="Branch location")
    contact_info: Optional[Dict[str, Any]] = Field(None, description="Contact information")

class ContractorCreate(ContractorBase):
    pass

class ContractorUpdate(BaseModel):
    name: Optional[str] = None
    branch: Optional[str] = None
    contact_info: Optional[Dict[str, Any]] = None

class Contractor(ContractorBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True