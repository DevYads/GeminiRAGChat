from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class DepartmentBase(BaseModel):
    name: str = Field(..., description="Department name")
    cost_center_code: Optional[str] = Field(None, description="Cost center code")
    plant_id: int = Field(..., description="Plant ID")

class DepartmentCreate(DepartmentBase):
    pass

class DepartmentUpdate(BaseModel):
    name: Optional[str] = None
    cost_center_code: Optional[str] = None
    plant_id: Optional[int] = None

class Department(DepartmentBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True