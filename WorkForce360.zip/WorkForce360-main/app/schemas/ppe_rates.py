from pydantic import BaseModel, Field
from typing import Optional
from decimal import Decimal
from datetime import datetime

class PPERateBase(BaseModel):
    code: str = Field(..., description="Unique PPE code")
    description: Optional[str] = Field(None, description="PPE description")
    rate: Decimal = Field(..., description="PPE rate")
    active_status: bool = Field(True, description="Active status")

class PPERateCreate(PPERateBase):
    pass

class PPERateUpdate(BaseModel):
    code: Optional[str] = None
    description: Optional[str] = None
    rate: Optional[Decimal] = None
    active_status: Optional[bool] = None

class PPERate(PPERateBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True