from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from io import BytesIO
from typing import List
import os

def generate_payroll_pdf(payroll_records: List[dict], month: int, year: int, plant_name: str = None) -> BytesIO:
    """Generate PDF report for payroll records"""
    
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    
    # Get sample styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=16,
        spaceAfter=30,
        alignment=1  # Center alignment
    )
    
    # Build content
    content = []
    
    # Title
    title_text = f"Payroll Report - {month}/{year}"
    if plant_name:
        title_text += f" - {plant_name}"
    title = Paragraph(title_text, title_style)
    content.append(title)
    content.append(Spacer(1, 12))
    
    # Table headers
    headers = [
        'Emp ID', 'Name', 'Days Worked', 'Total Hours', 
        'Gross Amount', 'PF Amount', 'ESIC Amount', 
        'Bonus Amount', 'PPE Amount', 'Net Pay'
    ]
    
    # Table data
    table_data = [headers]
    
    for record in payroll_records:
        row = [
            record.get('emp_id', ''),
            record.get('name', ''),
            str(record.get('total_days_worked', 0)),
            f"{record.get('total_hours', 0):.2f}",
            f"₹{record.get('gross_amount', 0):.2f}",
            f"₹{record.get('pf_amount', 0):.2f}",
            f"₹{record.get('esic_amount', 0):.2f}",
            f"₹{record.get('bonus_amount', 0):.2f}",
            f"₹{record.get('ppe_amount', 0):.2f}",
            f"₹{record.get('net_pay', 0):.2f}"
        ]
        table_data.append(row)
    
    # Create table
    table = Table(table_data)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('FONTSIZE', (0, 1), (-1, -1), 8),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey]),
    ]))
    
    content.append(table)
    
    # Build PDF
    doc.build(content)
    buffer.seek(0)
    
    return buffer

def save_payroll_pdf(payroll_records: List[dict], month: int, year: int, filename: str = None) -> str:
    """Save payroll PDF to file and return filepath"""
    
    if not filename:
        filename = f"payroll_{month}_{year}.pdf"
    
    # Create exports directory if it doesn't exist
    os.makedirs("exports", exist_ok=True)
    filepath = os.path.join("exports", filename)
    
    # Generate PDF
    pdf_buffer = generate_payroll_pdf(payroll_records, month, year)
    
    # Save to file
    with open(filepath, 'wb') as f:
        f.write(pdf_buffer.read())
    
    return filepath