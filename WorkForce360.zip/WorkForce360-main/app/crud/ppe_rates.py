from sqlalchemy.orm import Session
from typing import Optional, List

from .base import CRUDBase
from db.models.models import PPERate
from schemas.ppe_rates import PPERateCreate, PPERateUpdate

class CRUDPPERate(CRUDBase[PPERate, PPERateCreate, PPERateUpdate]):
    def get_by_code(self, db: Session, *, code: str) -> Optional[PPERate]:
        return db.query(PPERate).filter(PPERate.code == code).first()
    
    def get_active(self, db: Session) -> List[PPERate]:
        return db.query(PPERate).filter(PPERate.active_status == True).all()

ppe_rate = CRUDPPERate(PPERate)