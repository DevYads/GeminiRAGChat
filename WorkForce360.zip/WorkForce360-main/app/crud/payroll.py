from sqlalchemy.orm import Session
from typing import Optional, List

from .base import CRUDBase
from db.models.models import PayrollRecord
from schemas.payroll import PayrollRecordCreate

class CRUDPayrollRecord(CRUDBase[PayrollRecord, PayrollRecordCreate, None]):
    """CRUD operations for PayrollRecord - pure database operations only"""
    def get_by_labour_and_period(
        self, db: Session, *, labour_id: int, month: int, year: int
    ) -> Optional[PayrollRecord]:
        return db.query(PayrollRecord).filter(
            PayrollRecord.labour_id == labour_id,
            PayrollRecord.month == month,
            PayrollRecord.year == year
        ).first()
    
    def get_by_period(self, db: Session, *, month: int, year: int) -> List[PayrollRecord]:
        return db.query(PayrollRecord).filter(
            PayrollRecord.month == month,
            PayrollRecord.year == year
        ).all()

payroll = CRUDPayrollRecord(PayrollRecord)