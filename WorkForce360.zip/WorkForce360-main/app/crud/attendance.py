from sqlalchemy.orm import Session
from typing import List
from datetime import date

from .base import CRUDBase
from db.models.models import AttendanceSummary
from schemas.attendance import AttendanceSummaryCreate, AttendanceSummaryUpdate

class CRUDAttendanceSummary(CRUDBase[AttendanceSummary, AttendanceSummaryCreate, AttendanceSummaryUpdate]):
    """CRUD operations for AttendanceSummary - pure database operations only"""
    def get_by_labour_and_date_range(
        self, db: Session, *, labour_id: int, start_date: date, end_date: date
    ) -> List[AttendanceSummary]:
        return db.query(AttendanceSummary).filter(
            AttendanceSummary.labour_id == labour_id,
            AttendanceSummary.date >= start_date,
            AttendanceSummary.date <= end_date
        ).all()
    
    def get_by_month_year(
        self, db: Session, *, labour_id: int, month: int, year: int
    ) -> List[AttendanceSummary]:
        from calendar import monthrange
        start_date = date(year, month, 1)
        _, last_day = monthrange(year, month)
        end_date = date(year, month, last_day)
        return self.get_by_labour_and_date_range(db, labour_id=labour_id, start_date=start_date, end_date=end_date)

attendance = CRUDAttendanceSummary(AttendanceSummary)