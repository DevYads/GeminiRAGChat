from .base import CRUDBase
from db.models.models import Contractor
from schemas.contractors import ContractorCreate, ContractorUpdate

class CRUDContractor(CRUDBase[Contractor, ContractorCreate, ContractorUpdate]):
    pass

contractor = CRUDContractor(Contractor)