from sqlalchemy.orm import Session
from typing import List

from .base import CRUDBase
from db.models.models import Department
from schemas.departments import DepartmentCreate, DepartmentUpdate

class CRUDDepartment(CRUDBase[Department, DepartmentCreate, DepartmentUpdate]):
    def get_by_plant(self, db: Session, *, plant_id: int) -> List[Department]:
        return db.query(Department).filter(Department.plant_id == plant_id).all()

department = CRUDDepartment(Department)