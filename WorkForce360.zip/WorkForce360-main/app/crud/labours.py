from sqlalchemy.orm import Session
from typing import Optional, List

from .base import CRUDBase
from db.models.models import CasualLabour
from schemas.labours import CasualLabourCreate, CasualLabourUpdate

class CRUDCasualLabour(CRUDBase[CasualLabour, CasualLabourCreate, CasualLabourUpdate]):
    """CRUD operations for CasualLabour - pure database operations only"""
    def get_by_emp_id(self, db: Session, *, emp_id: str) -> Optional[CasualLabour]:
        return db.query(CasualLabour).filter(CasualLabour.emp_id == emp_id).first()
    
    def get_by_plant_and_contractor(self, db: Session, *, plant_id: int, contractor_id: int) -> List[CasualLabour]:
        return db.query(CasualLabour).filter(
            CasualLabour.plant_id == plant_id,
            CasualLabour.contractor_id == contractor_id
        ).all()
    
    def get_active(self, db: Session) -> List[CasualLabour]:
        return db.query(CasualLabour).filter(CasualLabour.active_status == True).all()

labour = CRUDCasualLabour(CasualLabour)