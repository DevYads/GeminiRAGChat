from sqlalchemy.orm import Session
from typing import Optional, List

from .base import CRUDBase
from db.models.models import Plant
from schemas.plants import PlantCreate, PlantUpdate

class CRUDPlant(CRUDBase[Plant, PlantCreate, PlantUpdate]):
    """CRUD operations for Plant - pure database operations only"""
    
    def get_by_code(self, db: Session, *, code: str) -> Optional[Plant]:
        """Get plant by code - raw DB query"""
        return db.query(Plant).filter(Plant.code == code).first()

    def get_by_location(self, db: Session, *, location: str) -> List[Plant]:
        """Get plants by location - raw DB query"""
        return db.query(Plant).filter(Plant.location == location).all()

plant = CRUDPlant(Plant)