from sqlalchemy.orm import Session
from typing import Optional

from .base import CRUDBase
from db.models.models import CasualGrade
from schemas.grades import CasualGradeCreate, CasualGradeUpdate

class CRUDCasualGrade(CRUDBase[CasualGrade, CasualGradeCreate, CasualGradeUpdate]):
    def get_by_code(self, db: Session, *, code: str) -> Optional[CasualGrade]:
        return db.query(CasualGrade).filter(CasualGrade.code == code).first()

grade = CRUDCasualGrade(CasualGrade)