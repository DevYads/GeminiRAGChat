from sqlalchemy import Column, Integer, String, Date, DateTime, Boolean, ForeignKey, Numeric, Text, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .base import Base

class Plant(Base):
    __tablename__ = "plants"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    location = Column(String(255))
    code = Column(String(50), unique=True, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    departments = relationship("Department", back_populates="plant")
    casual_labours = relationship("CasualLabour", back_populates="plant")

class Department(Base):
    __tablename__ = "departments"
    
    id = Column(Integer, primary_key=True, index=True)
    plant_id = Column(Integer, ForeignKey("plants.id"), nullable=False)
    name = Column(String(255), nullable=False)
    cost_center_code = Column(String(50))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    plant = relationship("Plant", back_populates="departments")
    casual_labours = relationship("CasualLabour", back_populates="department")

class Contractor(Base):
    __tablename__ = "contractors"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    branch = Column(String(255))
    contact_info = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    casual_labours = relationship("CasualLabour", back_populates="contractor")

class CasualGrade(Base):
    __tablename__ = "casual_grades"
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False)
    description = Column(Text)
    base_rate = Column(Numeric(10, 2), nullable=False)
    overtime_rate = Column(Numeric(10, 2), nullable=False)
    pf_applicable = Column(Boolean, default=False)
    pf_percent = Column(Numeric(5, 2))
    esic_applicable = Column(Boolean, default=False)
    esic_percent = Column(Numeric(5, 2))
    bonus_applicable = Column(Boolean, default=False)
    bonus_percent = Column(Numeric(5, 2))
    attendance_incentive_rate = Column(Numeric(10, 2))
    other_allowances = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    casual_labours = relationship("CasualLabour", back_populates="grade")

class PPERate(Base):
    __tablename__ = "ppe_rates"
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False)
    description = Column(Text)
    rate = Column(Numeric(10, 2), nullable=False)
    active_status = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    casual_labours = relationship("CasualLabour", back_populates="ppe_rate")

class CasualLabour(Base):
    __tablename__ = "casual_labours"
    
    id = Column(Integer, primary_key=True, index=True)
    emp_id = Column(String(50), unique=True, nullable=False)
    contractor_id = Column(Integer, ForeignKey("contractors.id"), nullable=False)
    plant_id = Column(Integer, ForeignKey("plants.id"), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    grade_id = Column(Integer, ForeignKey("casual_grades.id"), nullable=False)
    ppe_code = Column(String(50), ForeignKey("ppe_rates.code"))
    name = Column(String(255), nullable=False)
    gender = Column(String(10))
    aadhar = Column(String(12))
    active_status = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    contractor = relationship("Contractor", back_populates="casual_labours")
    plant = relationship("Plant", back_populates="casual_labours")
    department = relationship("Department", back_populates="casual_labours")
    grade = relationship("CasualGrade", back_populates="casual_labours")
    ppe_rate = relationship("PPERate", back_populates="casual_labours")
    attendance_records = relationship("AttendanceSummary", back_populates="labour")
    payroll_records = relationship("PayrollRecord", back_populates="labour")

class AttendanceSummary(Base):
    __tablename__ = "attendance_summary"
    
    id = Column(Integer, primary_key=True, index=True)
    labour_id = Column(Integer, ForeignKey("casual_labours.id"), nullable=False)
    date = Column(Date, nullable=False)
    shift_type = Column(String(10), nullable=False)  # 8Hr/12Hr
    hours_worked = Column(Numeric(4, 2))
    is_present = Column(Boolean, default=False)
    is_holiday = Column(Boolean, default=False)
    overtime_hours = Column(Numeric(4, 2), default=0)
    remarks = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    labour = relationship("CasualLabour", back_populates="attendance_records")

class PayrollRecord(Base):
    __tablename__ = "payroll_records"
    
    id = Column(Integer, primary_key=True, index=True)
    labour_id = Column(Integer, ForeignKey("casual_labours.id"), nullable=False)
    month = Column(Integer, nullable=False)
    year = Column(Integer, nullable=False)
    total_days_worked = Column(Integer, default=0)
    total_hours = Column(Numeric(6, 2), default=0)
    rate = Column(Numeric(10, 2))
    gross_amount = Column(Numeric(12, 2), default=0)
    pf_days = Column(Integer, default=0)
    pf_amount = Column(Numeric(10, 2), default=0)
    esic_amount = Column(Numeric(10, 2), default=0)
    bonus_days = Column(Integer, default=0)
    bonus_amount = Column(Numeric(10, 2), default=0)
    attendance_incentive = Column(Numeric(10, 2), default=0)
    ppe_rate = Column(Numeric(10, 2), default=0)
    ppe_amount = Column(Numeric(10, 2), default=0)
    canteen_deduction = Column(Numeric(10, 2), default=0)
    bus_deduction = Column(Numeric(10, 2), default=0)
    net_pay = Column(Numeric(12, 2), default=0)
    generated_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    labour = relationship("CasualLabour", back_populates="payroll_records")