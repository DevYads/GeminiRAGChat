from sqlalchemy import create_engine, Column, Integer, String, DateTime, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

# MS SQL Database connection for attendance punches
MSSQL_DATABASE_URL = os.getenv("MSSQL_DATABASE_URL", "mssql+pymssql://user:password@server/database")

mssql_engine = create_engine(MSSQL_DATABASE_URL)
MSSQLSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=mssql_engine)

AttendanceBase = declarative_base()

class AttendancePunch(AttendanceBase):
    """MS SQL table for raw attendance punches"""
    __tablename__ = "attendance_punches"
    
    id = Column(Integer, primary_key=True, index=True)
    emp_id = Column(String(50), nullable=False)
    punch_time = Column(DateTime, nullable=False)
    punch_type = Column(String(10), nullable=False)  # 'IN' or 'OUT'
    punch_date = Column(String(10), nullable=False)  # YYYY-MM-DD format
    machine_id = Column(String(20))
    
def get_attendance_db():
    """Get MS SQL database session for attendance punches"""
    db = MSSQLSessionLocal()
    try:
        yield db
    finally:
        db.close()