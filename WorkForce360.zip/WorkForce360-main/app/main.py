from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# Import all routers
from api import plants, departments, contractors, labours, attendance, payroll, grades, ppe_rates

app = FastAPI(
    title="WorkForce360",
    description="FastAPI Backend system to manage casual labour tracking, attendance, payroll, PPE, and compliance across multiple plants for a chemical manufacturing company.",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include all routers
app.include_router(plants.router, prefix="/api/v1")
app.include_router(departments.router, prefix="/api/v1")
app.include_router(contractors.router, prefix="/api/v1")
app.include_router(labours.router, prefix="/api/v1")
app.include_router(attendance.router, prefix="/api/v1")
app.include_router(payroll.router, prefix="/api/v1")
app.include_router(grades.router, prefix="/api/v1")
app.include_router(ppe_rates.router, prefix="/api/v1")

@app.get("/")
def read_root():
    return {
        "message": "WorkForce360 API",
        "version": "1.0.0",
        "docs": "/docs",
        "redoc": "/redoc"
    }

@app.get("/health")
def health_check():
    return {"status": "healthy"}

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"detail": f"Internal server error: {str(exc)}"}
    )

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=5000,
        reload=True
    )