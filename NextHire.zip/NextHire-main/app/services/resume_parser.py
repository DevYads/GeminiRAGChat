"""
AI-powered resume parsing service using Google Gemini
"""

import json
import base64
import io
import os
from typing import List, Dict, Any, Optional, Union, Tuple
from PyPDF2 import PdfReader
from app.schemas.candidate import ExtractedCandidateData

from app.schemas.ai_response_schemas import RESUME_SCHEMA

import google.generativeai as genai
from google.generativeai.types import GenerationConfig

class ResumeParsingService:
    def __init__(self):
        # Configure Gemini AI
        api_key = os.getenv("GOOGLE_API_KEY")
        if api_key and genai:
            try:
                genai.configure(api_key=api_key)
                self.model = genai.GenerativeModel('gemini-2.5-flash')
            except Exception as e:
                print(f"Error configuring Gemini AI: {e}")
                self.model = None
        else:
            self.model = None
    
    def extract_text_from_pdf(self, pdf_path: str) -> str:
        """Extract text from PDF resume"""
        try:
            reader = PdfReader(pdf_path)
            text = ""
            for page in reader.pages:
                text += page.extract_text() + "\n"
            return text.strip()
        except Exception as e:
            print(f"Error extracting PDF text: {e}")
            return ""

    def _read_pdf_to_base64(self, pdf_file: Union[str, io.BytesIO]) -> Tuple[bytes, str]:
        """
        Reads a PDF file (from path or BytesIO) and returns its content as base64 encoded string.
        Returns (raw_pdf_bytes, base64_string).
        """
        if isinstance(pdf_file, str): # If a file path is provided
            with open(pdf_file, "rb") as f:
                pdf_bytes = f.read()
        elif isinstance(pdf_file, io.BytesIO): # If a BytesIO object is provided
            pdf_bytes = pdf_file.getvalue()
        else:
            raise ValueError("pdf_file must be a file path (str) or a BytesIO object.")

        pdf_content_base64 = base64.b64encode(pdf_bytes).decode('utf-8')
        return pdf_bytes, pdf_content_base64

    def _call_gemini_structured_api(self, prompt: str, pdf_content_base64: str, response_schema: Dict[str, Any], model_name: str = "gemini-2.0-flash") -> Optional[Dict[str, Any]]:
        """
        Internal helper to call the Gemini API with a prompt, PDF content, and a structured response schema.
        Returns the parsed JSON response or None on error.
        """
        try:

            model = genai.GenerativeModel(
                model_name=model_name,
                generation_config=GenerationConfig(
                    response_mime_type="application/json",
                    response_schema=response_schema
                )
            )
            contents = [
                {"text": prompt},
                {
                    "inline_data": {
                        "mime_type": "application/pdf",
                        "data": pdf_content_base64
                    }
                }
            ]
            ai_response = model.generate_content(contents)
            response_text = ai_response.candidates[0].content.parts[0].text
            return json.loads(response_text)
        except json.JSONDecodeError as e:
            print(f"Error decoding Gemini API response JSON: {e}. Raw response: {response_text}")
            return None
        except Exception as e:
            print(f"Error calling Gemini API for structured extraction: {e}")
            return None


    def parse_resume_with_ai(self, resume_text: str, pdf_content_base64: str) -> Optional[Dict[str, Any]]:
        """Parse resume text using Google Gemini AI"""
        if not self.model:
            # Fallback parsing without AI
            return self._fallback_parsing(resume_text)
        
        prompt = """
         You are an expert AI assistant specializing in extracting key information from resume of .
         Analyze the following resume text and extract structured information in JSON format.
        
        Extract:
        1. Personal Information: name, contact (phone/address), email
        2. Education: degrees, institutions, years, grades/GPA
        3. Work Experience: companies, roles, start/end dates, descriptions
        4. Skills: technical and soft skills (normalize skill names, e.g., "Python" not "Python3")
        5. Job Roles: list of positions held
        6. Key Responsibilities: main duties and achievements
        7. Relevant Keywords: important terms for job matching
        8. Extra Info: certifications, languages, awards, etc.

        Ensure the JSON output strictly follows the provided schema
        """
        
        try:
            parsed_data = self._call_gemini_structured_api(prompt, pdf_content_base64, RESUME_SCHEMA)

            if isinstance(parsed_data, list):
                parsed_data = parsed_data[0]
            if parsed_data:
                print("Schema 1: Successfully extracted candidate details.")
                return parsed_data
            else:
                print("Schema 1: Failed to extract initial summary.")
                return self._fallback_parsing(resume_text)
            
        except Exception as e:
            print(f"Error parsing resume with AI: {e}")
            return self._fallback_parsing(resume_text)
    
    def _fallback_parsing(self, resume_text: str) -> Dict[str, Any]:
        """Basic fallback parsing without AI"""
        lines = resume_text.split('\n')
        
        # Extract email using simple pattern
        email = None
        for line in lines:
            if '@' in line and '.' in line:
                words = line.split()
                for word in words:
                    if '@' in word and '.' in word:
                        email = word.strip('.,;')
                        break
                if email:
                    break
        
        # Extract potential name (first few non-empty lines)
        name = None
        for line in lines[:5]:
            line = line.strip()
            if line and len(line.split()) >= 2 and not '@' in line:
                name = line
                break
        
        return {
            "name": name or "Unknown",
            "contact": "",
            "email": email or "",
            "education": [],
            "experience": [],
            "skills": [],
            "job_roles": [],
            "responsibilities": [],
            "relevant_keywords": [],
            "extra_info": {"note": "Parsed without AI - limited information extracted"}
        }
    
    def process_resume(self, pdf_path: str) -> Optional[ExtractedCandidateData]:
        """Complete resume processing pipeline"""
        # Extract text from PDF
        resume_text = self.extract_text_from_pdf(pdf_path)
        if not resume_text:
            return None

        # Read PDF to base64
        pdf_bytes, pdf_content_base64 = self._read_pdf_to_base64(pdf_path)
        if not pdf_content_base64:
            return None
        
        # Parse with AI
        parsed_data = self.parse_resume_with_ai(resume_text, pdf_content_base64)
        if not parsed_data:
            return None
        
        try:
            # Convert to Pydantic model for validation
            extracted_data = ExtractedCandidateData(**parsed_data)
            return extracted_data
        except Exception as e:
            print(f"Error creating ExtractedCandidateData: {e}")
            return None