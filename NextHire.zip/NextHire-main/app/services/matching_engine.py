"""
AI-powered candidate ranking and job matching service
"""

try:
    import google.generativeai as genai
except ImportError:
    genai = None

import json
import os
from typing import List, Dict, Any, Optional
from datetime import datetime
from sqlalchemy.orm import Session

from app.models.candidate import Candidate
from app.models.job import Job
from app.schemas.match import RankingDetails, CandidateRecommendation, JobMatchingResult

class CandidateMatchingService:
    def __init__(self):
        # Configure Gemini AI
        api_key = os.getenv("GOOGLE_API_KEY")
        if api_key and genai:
            try:
                genai.configure(api_key=api_key)
                self.model = genai.GenerativeModel('gemini-1.5-flash')
            except Exception as e:
                print(f"Error configuring Gemini AI: {e}")
                self.model = None
        else:
            self.model = None
    
    def analyze_candidate_job_match(self, candidate: Candidate, job: Job) -> Optional[Dict[str, Any]]:
        """Analyze how well a candidate matches a job using AI"""
        
        if not self.model:
            return self._fallback_matching(candidate, job)
        
        # Prepare candidate information
        candidate_info = {
            "name": candidate.name,
            "email": candidate.email,
            "extracted_data": candidate.extracted_json or {},
            "experiences": [
                {
                    "company": exp.company,
                    "role": exp.role,
                    "start_date": str(exp.start_date) if exp.start_date else None,
                    "end_date": str(exp.end_date) if exp.end_date else None,
                    "description": exp.description
                } for exp in candidate.experiences
            ],
            "skills": [skill.skill_name for skill in candidate.skills],
            "education": [
                {
                    "degree": edu.degree,
                    "institution": edu.institution,
                    "year": edu.year
                } for edu in candidate.educations
            ]
        }
        
        # Prepare job information
        job_info = {
            "title": job.title,
            "department": job.department,
            "description": job.description,
            "requirements": job.requirements_json or {},
            "required_skills": [skill.skill_name for skill in job.skills],
            "keywords": [keyword.keyword for keyword in job.keywords]
        }
        
        prompt = f"""
        Analyze the match between this candidate and job position. Provide a detailed assessment.
        
        CANDIDATE:
        {json.dumps(candidate_info, indent=2)}
        
        JOB POSITION:
        {json.dumps(job_info, indent=2)}
        
        Analyze and return ONLY valid JSON in this exact format:
        {{
            "overall_score": 85,
            "skills_overlap": {{
                "matched_skills": ["Python", "SQL", "JavaScript"],
                "missing_skills": ["React", "Docker"],
                "overlap_percentage": 75.5
            }},
            "experience_relevance": {{
                "relevant_roles": ["Software Developer", "Data Analyst"],
                "domain_match": true,
                "years_of_experience": 3.5
            }},
            "education_fit": {{
                "degree_match": true,
                "institution_relevance": "High",
                "education_level": "Bachelor's"
            }},
            "keyword_match": {{
                "matched_keywords": ["API", "Database", "Agile"],
                "keyword_coverage": 80.0
            }},
            "red_flags": {{
                "employment_gaps": ["6-month gap in 2022"],
                "irrelevant_experience": [],
                "missing_qualifications": ["Docker experience"]
            }},
            "need_clarifications": {{
                "ambiguous_info": ["Unclear project scope in role X"],
                "questions_for_candidate": ["Can you explain your Docker experience?"]
            }},
            "other_role_suggestions": {{
                "suggested_job_ids": [],
                "reasons": []
            }},
            "ai_reasoning": "This candidate shows strong technical skills matching 75% of requirements. The experience in similar roles is relevant, though some modern tools like Docker are missing. Overall a good fit with room for growth."
        }}
        
        Scoring Guidelines:
        - 90-100: Exceptional match, ready to hire
        - 80-89: Strong match, minor gaps
        - 70-79: Good match, some training needed
        - 60-69: Moderate match, significant gaps
        - Below 60: Poor match
        """
        
        try:
            response = self.model.generate_content(prompt)
            response_text = response.text.strip()
            
            # Extract JSON from response
            start_idx = response_text.find('{')
            end_idx = response_text.rfind('}') + 1
            
            if start_idx != -1 and end_idx != -1:
                json_text = response_text[start_idx:end_idx]
                analysis = json.loads(json_text)
                return analysis
            else:
                print("No valid JSON found in AI response")
                return self._fallback_matching(candidate, job)
                
        except Exception as e:
            print(f"Error analyzing candidate-job match: {e}")
            return self._fallback_matching(candidate, job)
    
    def _fallback_matching(self, candidate: Candidate, job: Job) -> Dict[str, Any]:
        """Basic fallback matching without AI"""
        candidate_skills = set(skill.skill_name.lower() for skill in candidate.skills)
        job_skills = set(skill.skill_name.lower() for skill in job.skills)
        
        # Simple skill overlap calculation
        if job_skills:
            skill_overlap = len(candidate_skills.intersection(job_skills)) / len(job_skills) * 100
        else:
            skill_overlap = 0
        
        # Basic scoring
        base_score = min(skill_overlap, 60)  # Cap at 60 for fallback
        
        return {
            "overall_score": base_score,
            "skills_overlap": {
                "matched_skills": list(candidate_skills.intersection(job_skills)),
                "missing_skills": list(job_skills - candidate_skills),
                "overlap_percentage": skill_overlap
            },
            "experience_relevance": {
                "relevant_roles": [exp.role for exp in candidate.experiences[:3]],
                "domain_match": True,
                "years_of_experience": len(candidate.experiences)
            },
            "education_fit": {
                "degree_match": len(candidate.educations) > 0,
                "institution_relevance": "Unknown",
                "education_level": candidate.educations[0].degree if candidate.educations else "Unknown"
            },
            "keyword_match": {
                "matched_keywords": [],
                "keyword_coverage": 0.0
            },
            "red_flags": {
                "employment_gaps": [],
                "irrelevant_experience": [],
                "missing_qualifications": []
            },
            "need_clarifications": {
                "ambiguous_info": [],
                "questions_for_candidate": []
            },
            "other_role_suggestions": {
                "suggested_job_ids": [],
                "reasons": []
            },
            "ai_reasoning": "Basic matching performed (AI unavailable). Score based on skill overlap only."
        }
    
    def rank_candidates_for_job(self, db: Session, job_id: int) -> Optional[JobMatchingResult]:
        """Rank all candidates for a specific job"""
        from app.crud.job import get_job
        from app.crud.candidate import get_candidates
        
        # Get job details
        job = get_job(db, job_id)
        if not job:
            return None
        
        # Get all candidates
        candidates = get_candidates(db, skip=0, limit=1000)
        
        candidate_rankings = []
        
        for candidate in candidates:
            analysis = self.analyze_candidate_job_match(candidate, job)
            if analysis:
                try:
                    ranking_details = RankingDetails(
                        skills_overlap=analysis["skills_overlap"],
                        experience_relevance=analysis["experience_relevance"],
                        education_fit=analysis["education_fit"],
                        keyword_match=analysis["keyword_match"],
                        red_flags=analysis["red_flags"],
                        need_clarifications=analysis["need_clarifications"],
                        other_role_suggestions=analysis["other_role_suggestions"],
                        ai_reasoning=analysis["ai_reasoning"]
                    )
                    
                    candidate_rec = CandidateRecommendation(
                        candidate_id=candidate.id,
                        candidate_name=candidate.name,
                        candidate_email=candidate.email,
                        score=analysis["overall_score"],
                        ranking_details=ranking_details
                    )
                    
                    candidate_rankings.append(candidate_rec)
                    
                except Exception as e:
                    print(f"Error creating ranking for candidate {candidate.id}: {e}")
                    continue
        
        # Sort by score (highest first)
        candidate_rankings.sort(key=lambda x: x.score, reverse=True)
        
        return JobMatchingResult(
            job_id=job.id,
            job_title=job.title,
            total_candidates_analyzed=len(candidates),
            ranked_candidates=candidate_rankings,
            analysis_timestamp=datetime.now()
        )