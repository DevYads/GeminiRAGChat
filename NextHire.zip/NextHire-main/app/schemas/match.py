"""
Pydantic schemas for job-candidate matching operations
"""

from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime

# Candidate ranking details
class SkillsOverlap(BaseModel):
    matched_skills: List[str]
    missing_skills: List[str]
    overlap_percentage: float

class ExperienceMatch(BaseModel):
    relevant_roles: List[str]
    domain_match: bool
    years_of_experience: Optional[float]

class EducationMatch(BaseModel):
    degree_match: bool
    institution_relevance: Optional[str]
    education_level: Optional[str]

class KeywordMatch(BaseModel):
    matched_keywords: List[str]
    keyword_coverage: float

class RedFlags(BaseModel):
    employment_gaps: List[str] = []
    irrelevant_experience: List[str] = []
    missing_qualifications: List[str] = []

class Clarifications(BaseModel):
    ambiguous_info: List[str] = []
    questions_for_candidate: List[str] = []

class OtherRoleSuggestions(BaseModel):
    suggested_job_ids: List[int] = []
    reasons: List[str] = []

class RankingDetails(BaseModel):
    """Detailed AI analysis for job-candidate matching"""
    skills_overlap: SkillsOverlap
    experience_relevance: ExperienceMatch
    education_fit: EducationMatch
    keyword_match: KeywordMatch
    red_flags: RedFlags
    need_clarifications: Clarifications
    other_role_suggestions: OtherRoleSuggestions
    ai_reasoning: str

# Job-Candidate match schemas
class JobCandidateMatchBase(BaseModel):
    job_id: int
    candidate_id: int
    score: float

class JobCandidateMatchCreate(JobCandidateMatchBase):
    ranking_details_json: Dict[str, Any]

class JobCandidateMatchResponse(JobCandidateMatchBase):
    id: int
    created_at: datetime
    ranking_details_json: Dict[str, Any]
    
    class Config:
        from_attributes = True

# Candidate recommendation with details
class CandidateRecommendation(BaseModel):
    candidate_id: int
    candidate_name: str
    candidate_email: str
    score: float
    ranking_details: RankingDetails
    
class JobMatchingResult(BaseModel):
    job_id: int
    job_title: str
    total_candidates_analyzed: int
    ranked_candidates: List[CandidateRecommendation]
    analysis_timestamp: datetime