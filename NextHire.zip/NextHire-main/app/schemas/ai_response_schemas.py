RESUME_SCHEMA = {
    "type": "object",
    "description": "Structured resume information extracted from PDF.",
    "properties": {
        "name": {"type": "string", "description": "Full name of the candidate."},
        "contact": {"type": "string", "description": "Primary phone number or address.", "nullable": True},
        "email": {"type": "string", "description": "Candidate’s primary email address.", "nullable": True},
        "education": {
            "type": "array",
            "description": "List of educational qualifications.",
            "items": {
                "type": "object",
                "properties": {
                    "degree": {"type": "string", "description": "Degree or certification title."},
                    "institution": {"type": "string", "description": "University/college name."},
                    "year": {"type": "integer", "description": "Year of completion.", "nullable": True},
                    "grade": {"type": "string", "description": "GPA, percentage or grade.", "nullable": True},
                },
                "required": ["degree", "institution"]
            }
        },
        "experience": {
            "type": "array",
            "description": "List of past work experiences.",
            "items": {
                "type": "object",
                "properties": {
                    "company": {"type": "string", "description": "Employer or company name."},
                    "role": {"type": "string", "description": "Job title/role."},
                    "start_date": {"type": "string", "description": "Start date in YYYY-MM-DD.", "nullable": True},
                    "end_date": {"type": "string", "description": "End date in YYYY-MM-DD.", "nullable": True},
                    "description": {"type": "string", "description": "Responsibilities, projects, achievements.", "nullable": True},
                },
                "required": ["company", "role"]
            }
        },
        "skills": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Technical and soft skills, normalized (e.g., Python, SQL, Communication)."
        },
        "job_roles": {
            "type": "array",
            "items": {"type": "string"},
            "description": "List of job roles/positions held."
        },
        "responsibilities": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Key responsibilities and achievements."
        },
        "relevant_keywords": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Important domain keywords extracted for matching (e.g., Agile, API, Database)."
        },
        "extra_info": {
            "type": "object",
            "description": "Other relevant information not captured above.",
            "properties": {
                "certifications": {"type": "array", "items": {"type": "string"}, "nullable": True},
                "languages": {"type": "array", "items": {"type": "string"}, "nullable": True},
                "awards": {"type": "array", "items": {"type": "string"}, "nullable": True}
            }
        }
    },
    "required": ["name", "email", "skills"]
}


CANDIDATE_JOB_MATCH_SCHEMA = {
    "type": "object",
    "description": "Structured analysis of how well a candidate matches a given job position.",
    "properties": {
        "overall_score": {
            "type": "number",
            "description": "Overall candidate-job match score from 0–100. Higher is better."
        },
        "skills_overlap": {
            "type": "object",
            "description": "Analysis of how candidate skills overlap with required job skills.",
            "properties": {
                "matched_skills": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of candidate skills that match job required skills."
                },
                "missing_skills": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Skills required by the job but missing from the candidate profile."
                },
                "overlap_percentage": {
                    "type": "number",
                    "description": "Percentage of job-required skills that the candidate has."
                }
            },
            "required": ["matched_skills", "missing_skills", "overlap_percentage"]
        },
        "experience_relevance": {
            "type": "object",
            "description": "Analysis of candidate’s work experience relevance to the job.",
            "properties": {
                "relevant_roles": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Candidate’s past roles relevant to the job position."
                },
                "domain_match": {
                    "type": "boolean",
                    "description": "Whether the candidate has worked in the same domain/industry."
                },
                "years_of_experience": {
                    "type": "number",
                    "description": "Total number of relevant years of experience."
                }
            },
            "required": ["relevant_roles", "domain_match", "years_of_experience"]
        },
        "education_fit": {
            "type": "object",
            "description": "Comparison of candidate education vs job requirements.",
            "properties": {
                "degree_match": {
                    "type": "boolean",
                    "description": "Whether the candidate’s degree meets the job’s required degree level."
                },
                "institution_relevance": {
                    "type": "string",
                    "description": "Relevance/recognition of candidate’s institution (e.g., High, Medium, Low)."
                },
                "education_level": {
                    "type": "string",
                    "description": "Highest education level (e.g., Bachelor's, Master's, PhD)."
                }
            },
            "required": ["degree_match", "institution_relevance", "education_level"]
        },
        "keyword_match": {
            "type": "object",
            "description": "Keyword overlap analysis between job description and candidate profile.",
            "properties": {
                "matched_keywords": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Keywords from the job found in the candidate’s resume/profile."
                },
                "keyword_coverage": {
                    "type": "number",
                    "description": "Percentage of job keywords found in candidate profile."
                }
            },
            "required": ["matched_keywords", "keyword_coverage"]
        },
        "red_flags": {
            "type": "object",
            "description": "Potential concerns or risks about the candidate.",
            "properties": {
                "employment_gaps": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Notable gaps in candidate employment history with dates."
                },
                "irrelevant_experience": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Past experiences not relevant to the applied job."
                },
                "missing_qualifications": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Qualifications required by the job but missing in candidate profile."
                }
            },
            "required": ["employment_gaps", "irrelevant_experience", "missing_qualifications"]
        },
        "need_clarifications": {
            "type": "object",
            "description": "Additional clarifications/questions needed from candidate.",
            "properties": {
                "ambiguous_info": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Unclear details in candidate’s resume that require clarification."
                },
                "questions_for_candidate": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Specific questions to ask the candidate during interview."
                }
            },
            "required": ["ambiguous_info", "questions_for_candidate"]
        },
        "other_role_suggestions": {
            "type": "object",
            "description": "Suggestions for other roles the candidate might be a fit for.",
            "properties": {
                "suggested_job_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of alternative job IDs the candidate could match."
                },
                "reasons": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Reasons why candidate is suggested for these alternative roles."
                }
            },
            "required": ["suggested_job_ids", "reasons"]
        },
        "ai_reasoning": {
            "type": "string",
            "description": "Natural language reasoning by AI explaining the match evaluation."
        }
    },
    "required": [
        "overall_score",
        "skills_overlap",
        "experience_relevance",
        "education_fit",
        "keyword_match",
        "red_flags",
        "need_clarifications",
        "other_role_suggestions",
        "ai_reasoning"
    ]
}