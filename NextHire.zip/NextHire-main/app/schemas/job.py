"""
Pydantic schemas for job-related operations
"""

from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime

# Base schemas for job skills and keywords
class JobSkillBase(BaseModel):
    skill_name: str
    required_level: Optional[str] = None
    importance_weight: float = 1.0

class JobKeywordBase(BaseModel):
    keyword: str
    weight: float = 1.0

# Response schemas (include IDs)
class JobSkillResponse(JobSkillBase):
    id: int
    job_id: int
    
    class Config:
        from_attributes = True

class JobKeywordResponse(JobKeywordBase):
    id: int
    job_id: int
    
    class Config:
        from_attributes = True

# Main job schemas
class JobBase(BaseModel):
    title: str
    department: Optional[str] = None
    description: str
    requirements_json: Optional[Dict[str, Any]] = None

class JobCreate(JobBase):
    skills: List[JobSkillBase] = []
    keywords: List[JobKeywordBase] = []

class JobResponse(JobBase):
    id: int
    created_at: datetime
    skills: List[JobSkillResponse] = []
    keywords: List[JobKeywordResponse] = []
    
    class Config:
        from_attributes = True

# Job listing for search results
class JobSummary(BaseModel):
    id: int
    title: str
    department: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True