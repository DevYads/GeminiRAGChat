"""
Pydantic schemas for candidate-related operations
"""

from pydantic import BaseModel, EmailStr, ConfigDict
from typing import Optional, List, Dict, Any
from datetime import date, datetime

# Base schemas for experiences, education, skills
class CandidateExperienceBase(BaseModel):
    company: Optional[str]
    role: Optional[str]
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    description: Optional[str] = None

class CandidateEducationBase(BaseModel):
    degree: Optional[str]
    institution: Optional[str]
    year: Optional[int] = None
    grade: Optional[str] = None

class CandidateSkillBase(BaseModel):
    skill_name: str
    level: Optional[str] = None
    years_of_experience: Optional[float] = None

class CandidateKeywordBase(BaseModel):
    keyword: str
    weight: float = 1.0

# Response schemas (include IDs)
class CandidateExperienceResponse(CandidateExperienceBase):
    id: int
    candidate_id: int
    
    class Config:
        from_attributes = True

class CandidateEducationResponse(CandidateEducationBase):
    id: int
    candidate_id: int
    
    class Config:
        from_attributes = True

class CandidateSkillResponse(CandidateSkillBase):
    id: int
    candidate_id: int
    
    class Config:
        from_attributes = True

class CandidateKeywordResponse(CandidateKeywordBase):
    id: int
    candidate_id: int
    
    class Config:
        from_attributes = True

# Main candidate schemas
class CandidateBase(BaseModel):
    name: str
    email: EmailStr
    phone: Optional[str] = None

class CandidateCreate(CandidateBase):
    pass

class CandidateResponse(CandidateBase):
    id: int
    resume_path: Optional[str] = None
    extracted_json: Optional[Dict[str, Any]] = None
    created_at: datetime
    experiences: List[CandidateExperienceResponse] = []
    educations: List[CandidateEducationResponse] = []
    skills: List[CandidateSkillResponse] = []
    keywords: List[CandidateKeywordResponse] = []
    
    class Config:
        from_attributes = True

# AI-extracted candidate data schema
class ExtractedCandidateData(BaseModel):
    """Schema for AI-extracted candidate information from resume"""
    name: str
    contact: Optional[str] = None
    email: Optional[str] = None
    education: List[Dict[str, Any]] = []
    experience: List[Dict[str, Any]] = []
    skills: List[str] = []
    job_roles: List[str] = []
    responsibilities: List[str] = []
    relevant_keywords: List[str] = []
    extra_info: Optional[Dict[str, Any]] = None

    model_config = ConfigDict(from_attributes=True)

# File upload schema
class CandidateUploadResponse(BaseModel):
    candidate_id: int
    message: str
    extracted_data: Optional[ExtractedCandidateData] = None