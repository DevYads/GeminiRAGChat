"""
CRUD operations for candidates
"""

from sqlalchemy.orm import Session
from typing import List, Optional
from app.models.candidate import Candidate, CandidateExperience, CandidateEducation, CandidateSkill, CandidateKeyword
from app.schemas.candidate import CandidateCreate, ExtractedCandidateData

def get_candidate(db: Session, candidate_id: int) -> Optional[Candidate]:
    """Get a candidate by ID"""
    return db.query(Candidate).filter(Candidate.id == candidate_id).first()

def get_candidate_by_email(db: Session, email: str) -> Optional[Candidate]:
    """Get a candidate by email"""
    return db.query(Candidate).filter(Candidate.email == email).first()

def get_candidates(db: Session, skip: int = 0, limit: int = 100) -> List[Candidate]:
    """Get all candidates with pagination"""
    return db.query(Candidate).offset(skip).limit(limit).all()

def create_candidate(db: Session, candidate: CandidateCreate, resume_path: Optional[str] = None) -> Candidate:
    """Create a new candidate"""
    db_candidate = Candidate(
        name=candidate.name,
        email=candidate.email,
        phone=candidate.phone,
        resume_path=resume_path
    )
    db.add(db_candidate)
    db.commit()
    db.refresh(db_candidate)
    return db_candidate

def update_candidate_extracted_data(db: Session, candidate_id: int, extracted_data: dict) -> Optional[Candidate]:
    """Update candidate with AI-extracted data"""
    candidate = db.query(Candidate).filter(Candidate.id == candidate_id).first()
    if candidate:
        # Update the extracted_json field
        db.query(Candidate).filter(Candidate.id == candidate_id).update(
            {"extracted_json": extracted_data}
        )
        db.commit()
        db.refresh(candidate)
    return candidate

def add_candidate_experiences(db: Session, candidate_id: int, experiences: List[dict]) -> List[CandidateExperience]:
    """Add experiences to a candidate"""
    db_experiences = []
    for exp in experiences:
        db_exp = CandidateExperience(
            candidate_id=candidate_id,
            company=exp.get('company', ''),
            role=exp.get('role', ''),
            start_date=exp.get('start_date'),
            end_date=exp.get('end_date'),
            description=exp.get('description', '')
        )
        db.add(db_exp)
        db_experiences.append(db_exp)
    
    db.commit()
    for exp in db_experiences:
        db.refresh(exp)
    return db_experiences

def add_candidate_skills(db: Session, candidate_id: int, skills: List[str]) -> List[CandidateSkill]:
    """Add skills to a candidate"""
    db_skills = []
    for skill in skills:
        db_skill = CandidateSkill(
            candidate_id=candidate_id,
            skill_name=skill,
            # level="Unknown"
        )
        db.add(db_skill)
        db_skills.append(db_skill)
    
    db.commit()
    for skill in db_skills:
        db.refresh(skill)
    return db_skills

def delete_candidate(db: Session, candidate_id: int) -> bool:
    """Delete a candidate"""
    candidate = db.query(Candidate).filter(Candidate.id == candidate_id).first()
    if candidate:
        db.delete(candidate)
        db.commit()
        return True
    return False