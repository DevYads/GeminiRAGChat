"""
CRUD operations for jobs
"""

from sqlalchemy.orm import Session
from typing import List, Optional
from app.models.job import Job, JobSkill, JobKeyword
from app.schemas.job import JobCreate

def get_job(db: Session, job_id: int) -> Optional[Job]:
    """Get a job by ID"""
    return db.query(Job).filter(Job.id == job_id).first()

def get_jobs(db: Session, skip: int = 0, limit: int = 100) -> List[Job]:
    """Get all jobs with pagination"""
    return db.query(Job).offset(skip).limit(limit).all()

def create_job(db: Session, job: JobCreate) -> Job:
    """Create a new job with skills and keywords"""
    db_job = Job(
        title=job.title,
        department=job.department,
        description=job.description,
        requirements_json=job.requirements_json
    )
    db.add(db_job)
    db.commit()
    db.refresh(db_job)
    
    # Add skills
    if job.skills:
        for skill in job.skills:
            db_skill = JobSkill(
                job_id=db_job.id,
                skill_name=skill.skill_name,
                required_level=skill.required_level,
                importance_weight=skill.importance_weight
            )
            db.add(db_skill)
    
    # Add keywords
    if job.keywords:
        for keyword in job.keywords:
            db_keyword = JobKeyword(
                job_id=db_job.id,
                keyword=keyword.keyword,
                weight=keyword.weight
            )
            db.add(db_keyword)
    
    db.commit()
    db.refresh(db_job)
    return db_job

def update_job(db: Session, job_id: int, job_update: dict) -> Optional[Job]:
    """Update a job"""
    job = db.query(Job).filter(Job.id == job_id).first()
    if job:
        for key, value in job_update.items():
            setattr(job, key, value)
        db.commit()
        db.refresh(job)
    return job

def delete_job(db: Session, job_id: int) -> bool:
    """Delete a job"""
    job = db.query(Job).filter(Job.id == job_id).first()
    if job:
        db.delete(job)
        db.commit()
        return True
    return False

def search_jobs_by_title(db: Session, title_query: str) -> List[Job]:
    """Search jobs by title"""
    return db.query(Job).filter(Job.title.ilike(f"%{title_query}%")).all()