"""
Candidate-related database models
"""

from sqlalchemy import Column, Integer, String, DateTime, Text, JSON, ForeignKey, Float, Date
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base

class Candidate(Base):
    __tablename__ = "candidates"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    phone = Column(String(50))
    resume_path = Column(String(500))
    extracted_json = Column(JSON)  # Stores AI-extracted candidate data
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    experiences = relationship("CandidateExperience", back_populates="candidate", cascade="all, delete-orphan")
    educations = relationship("CandidateEducation", back_populates="candidate", cascade="all, delete-orphan")
    skills = relationship("CandidateSkill", back_populates="candidate", cascade="all, delete-orphan")
    keywords = relationship("CandidateKeyword", back_populates="candidate", cascade="all, delete-orphan")
    job_matches = relationship("JobCandidateMatch", back_populates="candidate")

class CandidateExperience(Base):
    __tablename__ = "candidate_experiences"
    
    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)
    company = Column(String(255), nullable=True)
    role = Column(String(255), nullable=True)
    start_date = Column(Date)
    end_date = Column(Date)  # NULL means current position
    description = Column(Text)
    
    candidate = relationship("Candidate", back_populates="experiences")

class CandidateEducation(Base):
    __tablename__ = "candidate_educations"
    
    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)
    degree = Column(String(255), nullable=True)
    institution = Column(String(255), nullable=True)
    year = Column(Integer)
    grade = Column(String(50))
    
    candidate = relationship("Candidate", back_populates="educations")

class CandidateSkill(Base):
    __tablename__ = "candidate_skills"
    
    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)
    skill_name = Column(String(255), nullable=False, index=True)
    level = Column(String(50))  # Beginner, Intermediate, Advanced, Expert
    years_of_experience = Column(Float)
    embedding_vector = Column(Text)  # For AI similarity matching
    
    candidate = relationship("Candidate", back_populates="skills")

class CandidateKeyword(Base):
    __tablename__ = "candidate_extracted_keywords"
    
    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)
    keyword = Column(String(255), nullable=False, index=True)
    weight = Column(Float, default=1.0)  # Importance/relevance weight
    
    candidate = relationship("Candidate", back_populates="keywords")