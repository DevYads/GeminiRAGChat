"""
Job-Candidate matching database models
"""

from sqlalchemy import Column, Integer, ForeignKey, Float, JSON, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base

class JobCandidateMatch(Base):
    __tablename__ = "job_candidate_matches"
    
    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)
    candidate_id = Column(Integer, ForeignKey("candidates.id"), nullable=False)
    score = Column(Float, nullable=False, index=True)  # Overall matching score 0-100
    ranking_details_json = Column(JSON)  # Detailed AI analysis results
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    job = relationship("Job", back_populates="candidate_matches")
    candidate = relationship("Candidate", back_populates="job_matches")

    
    def __repr__(self):
        return f"<JobCandidateMatch(job_id={self.job_id}, candidate_id={self.candidate_id}, score={self.score})>"