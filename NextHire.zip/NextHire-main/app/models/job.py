"""
Job-related database models
"""

from sqlalchemy import Column, Integer, String, DateTime, Text, JSON, ForeignKey, Float
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.base import Base

class Job(Base):
    __tablename__ = "jobs"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False, index=True)
    department = Column(String(255), index=True)
    description = Column(Text, nullable=False)
    requirements_json = Column(JSON)  # Structured job requirements
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    skills = relationship("JobSkill", back_populates="job", cascade="all, delete-orphan")
    keywords = relationship("JobKeyword", back_populates="job", cascade="all, delete-orphan")
    candidate_matches = relationship("JobCandidateMatch", back_populates="job")

class JobSkill(Base):
    __tablename__ = "job_skills"
    
    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)
    skill_name = Column(String(255), nullable=False, index=True)
    required_level = Column(String(50))  # Beginner, Intermediate, Advanced, Expert
    importance_weight = Column(Float, default=1.0)  # How critical this skill is
    embedding_vector = Column(Text)  # For AI similarity matching
    
    job = relationship("Job", back_populates="skills")

class JobKeyword(Base):
    __tablename__ = "job_keywords"
    
    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)
    keyword = Column(String(255), nullable=False, index=True)
    weight = Column(Float, default=1.0)  # Importance weight
    
    job = relationship("Job", back_populates="keywords")