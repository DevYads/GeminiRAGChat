"""
Candidate API endpoints
"""

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List
import os
import shutil
from datetime import datetime

from app.db.base import get_db
from app.schemas.candidate import CandidateResponse, CandidateCreate, CandidateUploadResponse
from app.crud import candidate as candidate_crud
from app.services.resume_parser import ResumeParsingService

router = APIRouter(prefix="/candidates", tags=["candidates"])

@router.post("/upload", response_model=CandidateUploadResponse)
async def upload_candidate_resume(
    name: str = Form(...),
    email: str = Form(...),
    phone: str = Form(None),
    resume: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload resume PDF, extract info using AI, save candidate + details in DB"""
    
    # Validate file type
    if not resume.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")
    
    # Check if candidate with email already exists
    existing_candidate = candidate_crud.get_candidate_by_email(db, email)
    if existing_candidate:
        raise HTTPException(status_code=400, detail="Candidate with this email already exists")
    
    try:
        # Create uploads directory if it doesn't exist
        os.makedirs("uploads", exist_ok=True)
        
        # Save uploaded file
        timestamp = datetime.now().strftime("%Y%m%d")
        filename = f"{timestamp}_{resume.filename}"
        file_path = os.path.join("uploads", filename)
        
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(resume.file, buffer)
        
        # Create candidate record
        candidate_data = CandidateCreate(name=name, email=email, phone=phone)
        db_candidate = candidate_crud.create_candidate(db, candidate_data, file_path)
        
        # Parse resume with AI
        parser = ResumeParsingService()
        extracted_data = parser.process_resume(file_path)
        
        if extracted_data:
            # Update candidate with extracted data
            candidate_crud.update_candidate_extracted_data(
                db, 
                db_candidate.id, 
                extracted_data.model_dump(mode='json')
            )
            
            # Add structured data to database
            if extracted_data.experience:
                candidate_crud.add_candidate_experiences(
                    db, 
                    db_candidate.id, 
                    extracted_data.experience
                )
            
            if extracted_data.skills:
                candidate_crud.add_candidate_skills(
                    db, 
                    db_candidate.id, 
                    extracted_data.skills
                )
            
            return CandidateUploadResponse(
                candidate_id=db_candidate.id,
                message="Resume uploaded and processed successfully",
                extracted_data=extracted_data
            )
        else:
            return CandidateUploadResponse(
                candidate_id=db_candidate.id,
                message="Resume uploaded but AI processing failed. Basic candidate record created.",
                extracted_data=None
            )
            
    except Exception as e:
        # Clean up uploaded file on error
        if os.path.exists(file_path):
            os.remove(file_path)
        raise HTTPException(status_code=500, detail=f"Error processing resume: {str(e)}")

@router.get("/{candidate_id}", response_model=CandidateResponse)
def get_candidate(candidate_id: int, db: Session = Depends(get_db)):
    """Fetch candidate details by ID"""
    candidate = candidate_crud.get_candidate(db, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")
    return candidate

@router.get("/", response_model=List[CandidateResponse])
def list_candidates(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """List all candidates with pagination"""
    candidates = candidate_crud.get_candidates(db, skip=skip, limit=limit)
    return candidates

@router.delete("/{candidate_id}")
def delete_candidate(candidate_id: int, db: Session = Depends(get_db)):
    """Delete a candidate"""
    success = candidate_crud.delete_candidate(db, candidate_id)
    if not success:
        raise HTTPException(status_code=404, detail="Candidate not found")
    return {"message": "Candidate deleted successfully"}