"""
HR Workflow APIs for enhanced candidate management
"""

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List, Optional
import os
import shutil
from datetime import datetime

from app.db.base import get_db
from app.schemas.candidate import CandidateResponse, CandidateCreate
from app.schemas.match import JobCandidateMatchResponse, CandidateRecommendation, RankingDetails
from app.crud import candidate as candidate_crud, job as job_crud
from app.services.resume_parser import ResumeParsingService
from app.services.matching_engine import CandidateMatchingService
from app.models.match import JobCandidateMatch

router = APIRouter(prefix="/jobs", tags=["hr-workflows"])

# Single Candidate to Job Match API
@router.post("/{job_id}/candidates/upload")
async def upload_candidate_and_match(
    job_id: int,
    name: str = Form(...),
    email: str = Form(...),
    phone: str = Form(None),
    resume: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload candidate resume PDF, extract details, create candidate entry, run matching"""
    
    # Verify job exists
    job = job_crud.get_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    # Validate file type
    if not resume.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")
    
    # Check if candidate with email already exists
    existing_candidate = candidate_crud.get_candidate_by_email(db, email)
    if existing_candidate:
        # Use existing candidate for matching
        candidate = existing_candidate
    else:
        try:
            # Create uploads directory if it doesn't exist
            os.makedirs("uploads", exist_ok=True)
            
            # Save uploaded file
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{timestamp}_{resume.filename}"
            file_path = os.path.join("uploads", filename)
            
            with open(file_path, "wb") as buffer:
                shutil.copyfileobj(resume.file, buffer)
            
            # Create candidate record
            candidate_data = CandidateCreate(name=name, email=email, phone=phone)
            candidate = candidate_crud.create_candidate(db, candidate_data, file_path)
            
            # Parse resume with AI
            parser = ResumeParsingService()
            extracted_data = parser.process_resume(file_path)
            
            if extracted_data:
                candidate_crud.update_candidate_extracted_data(
                    db, candidate.id, extracted_data.dict()
                )
                
                if extracted_data.experience:
                    candidate_crud.add_candidate_experiences(
                        db, candidate.id, extracted_data.experience
                    )
                
                if extracted_data.skills:
                    candidate_crud.add_candidate_skills(
                        db, candidate.id, extracted_data.skills
                    )
        
        except Exception as e:
            if 'file_path' in locals() and os.path.exists(file_path):
                os.remove(file_path)
            raise HTTPException(status_code=500, detail=f"Error processing resume: {str(e)}")
    
    # Run matching analysis
    try:
        matching_service = CandidateMatchingService()
        analysis = matching_service.analyze_candidate_job_match(candidate, job)
        
        if analysis:
            # Save match result
            match = JobCandidateMatch(
                job_id=job_id,
                candidate_id=candidate.id,
                score=analysis["overall_score"],
                ranking_details_json=analysis
            )
            db.add(match)
            db.commit()
            db.refresh(match)
            
            return {
                "candidate_id": candidate.id,
                "job_id": job_id,
                "match_id": match.id,
                "score": analysis["overall_score"],
                "status": "success"
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to analyze candidate-job match")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error running matching analysis: {str(e)}")

# Get Job's Candidate Rankings API
@router.get("/{job_id}/matches")
def get_job_candidate_matches(job_id: int, db: Session = Depends(get_db)):
    """Return all candidate matches for a job, ranked by score"""
    
    # Verify job exists
    job = job_crud.get_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    # Get all matches for this job, ordered by score
    matches = db.query(JobCandidateMatch).filter(
        JobCandidateMatch.job_id == job_id
    ).order_by(JobCandidateMatch.score.desc()).all()
    
    # Format response with candidate details
    result = []
    for match in matches:
        candidate = candidate_crud.get_candidate(db, match.candidate_id)
        if candidate:
            # Extract overlap summary from ranking details
            ranking_details = match.ranking_details_json or {}
            skills_overlap = ranking_details.get("skills_overlap", {})
            
            result.append({
                "match_id": match.id,
                "candidate_id": candidate.id,
                "candidate_name": candidate.name,
                "candidate_email": candidate.email,
                "score": match.score,
                "overlap_summary": {
                    "matched_skills": skills_overlap.get("matched_skills", []),
                    "overlap_percentage": skills_overlap.get("overlap_percentage", 0),
                    "missing_skills_count": len(skills_overlap.get("missing_skills", []))
                },
                "created_at": match.created_at
            })
    
    return {
        "job_id": job_id,
        "job_title": job.title,
        "total_matches": len(result),
        "matches": result
    }

# Analytics APIs
analytics_router = APIRouter(prefix="/analytics", tags=["analytics"])

@analytics_router.get("/top-candidates")
def get_top_candidates(job_id: int, limit: int = 10, db: Session = Depends(get_db)):
    """Return top-N candidates for a job"""
    
    # Verify job exists
    job = job_crud.get_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    # Get top candidates
    matches = db.query(JobCandidateMatch).filter(
        JobCandidateMatch.job_id == job_id
    ).order_by(JobCandidateMatch.score.desc()).limit(limit).all()
    
    top_candidates = []
    for match in matches:
        candidate = candidate_crud.get_candidate(db, match.candidate_id)
        if candidate:
            top_candidates.append({
                "candidate_id": candidate.id,
                "name": candidate.name,
                "email": candidate.email,
                "score": match.score,
                "skills": [skill.skill_name for skill in candidate.skills],
                "experience_years": len(candidate.experiences),
                "match_id": match.id
            })
    
    return {
        "job_id": job_id,
        "job_title": job.title,
        "top_candidates": top_candidates
    }

@analytics_router.get("/red-flags")
def get_candidates_with_red_flags(job_id: int, db: Session = Depends(get_db)):
    """Show candidates with potential risks"""
    
    # Verify job exists
    job = job_crud.get_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    # Get all matches for this job
    matches = db.query(JobCandidateMatch).filter(
        JobCandidateMatch.job_id == job_id
    ).all()
    
    candidates_with_flags = []
    for match in matches:
        ranking_details = match.ranking_details_json or {}
        red_flags = ranking_details.get("red_flags", {})
        
        # Check if there are any red flags
        has_flags = (
            red_flags.get("employment_gaps", []) or
            red_flags.get("irrelevant_experience", []) or
            red_flags.get("missing_qualifications", [])
        )
        
        if has_flags:
            candidate = candidate_crud.get_candidate(db, match.candidate_id)
            if candidate:
                candidates_with_flags.append({
                    "candidate_id": candidate.id,
                    "name": candidate.name,
                    "email": candidate.email,
                    "score": match.score,
                    "red_flags": red_flags,
                    "match_id": match.id
                })
    
    return {
        "job_id": job_id,
        "job_title": job.title,
        "candidates_with_red_flags": candidates_with_flags
    }

@analytics_router.get("/suggestions")
def get_alternative_job_suggestions(candidate_id: int, db: Session = Depends(get_db)):
    """List alternative job roles suggested by AI for a candidate"""
    
    # Verify candidate exists
    candidate = candidate_crud.get_candidate(db, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")
    
    # Get all matches for this candidate
    matches = db.query(JobCandidateMatch).filter(
        JobCandidateMatch.candidate_id == candidate_id
    ).all()
    
    all_suggestions = []
    for match in matches:
        ranking_details = match.ranking_details_json or {}
        suggestions = ranking_details.get("other_role_suggestions", {})
        
        if suggestions.get("suggested_job_ids"):
            suggested_ids = suggestions["suggested_job_ids"]
            reasons = suggestions.get("reasons", [])
            
            # Get job details for suggested IDs
            for i, job_id in enumerate(suggested_ids):
                job = job_crud.get_job(db, job_id)
                if job:
                    all_suggestions.append({
                        "job_id": job_id,
                        "job_title": job.title,
                        "department": job.department,
                        "reason": reasons[i] if i < len(reasons) else "Alternative role suggested by AI",
                        "from_match_id": match.id
                    })
    
    return {
        "candidate_id": candidate_id,
        "candidate_name": candidate.name,
        "alternative_suggestions": all_suggestions
    }