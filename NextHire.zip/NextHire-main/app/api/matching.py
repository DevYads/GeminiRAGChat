"""
Matching and Recommendation API endpoints
"""

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from datetime import datetime

from app.db.base import get_db
from app.schemas.match import JobMatchingResult, JobCandidateMatchCreate, JobCandidateMatchResponse
from app.services.matching_engine import CandidateMatchingService
from app.crud.job import get_job
from app.crud.candidate import get_candidate
from app.models.match import JobCandidateMatch

from typing import List, Optional, Dict


from app.schemas.match import CandidateRecommendation, RankingDetails
from app.crud.candidate import get_candidate

router = APIRouter(prefix="/jobs", tags=["matching"])

@router.post("/job/{job_id}/match", response_model=JobMatchingResult)
def run_candidate_matching(
    job_id: int,
    candidate_ids: List[int],
    db: Session = Depends(get_db),
    background_tasks: BackgroundTasks = BackgroundTasks()
):
    """Run AI-powered candidate ranking for this job"""
    
    # Verify job exists
    job = get_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    # Verify candidate exists
    for candidate_id in candidate_ids:
        candidate = get_candidate(db, candidate_id)
        if not candidate:
            raise HTTPException(status_code=404, detail=f"Candidate {candidate_id} not found")
    
    try:
        # Run matching analysis
        matching_service = CandidateMatchingService()
        result = matching_service.rank_candidate_for_job(db, job_id, candidate_ids)
        
        if not result:
            raise HTTPException(status_code=500, detail="Failed to analyze candidates")
        
        # Store results in background
        background_tasks.add_task(store_matching_results, db, result)
        
        return result
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error running candidate matching: {str(e)}")

@router.get("/{job_id}/recommendations", response_model=JobMatchingResult)
def get_candidate_recommendations(job_id: int, db: Session = Depends(get_db)):
    """Get cached ranked candidates with scores & explanations"""
    
    # Verify job exists
    job = get_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    # Get latest matches for this job
    matches = db.query(JobCandidateMatch).filter(
        JobCandidateMatch.job_id == job_id
    ).order_by(JobCandidateMatch.score.desc()).all()
    
    if not matches:
        raise HTTPException(
            status_code=404, 
            detail="No candidate recommendations found. Run matching analysis first."
        )
    
    # Convert stored matches to response format
    
    ranked_candidates = []
    for match in matches:
        candidate = get_candidate(db, match.candidate_id)
        if candidate and match.ranking_details_json:
            try:
                ranking_details = RankingDetails(**match.ranking_details_json)
                
                candidate_rec = CandidateRecommendation(
                    candidate_id=candidate.id,
                    candidate_name=candidate.name,
                    candidate_email=candidate.email,
                    score=match.score,
                    ranking_details=ranking_details
                )
                ranked_candidates.append(candidate_rec)
            except Exception as e:
                print(f"Error processing match {match.id}: {e}")
                continue
    
    return JobMatchingResult(
        job_id=job.id,
        job_title=job.title,
        total_candidates_analyzed=len(ranked_candidates),
        ranked_candidates=ranked_candidates,
        analysis_timestamp=matches[0].created_at if matches else datetime.now()
    )

def store_matching_results(db: Session, result: JobMatchingResult):
    """Background task to store matching results"""
    try:
        # Delete existing matches for this job
        db.query(JobCandidateMatch).filter(
            JobCandidateMatch.job_id == result.job_id
        ).delete()
        
        # Store new matches
        for candidate_rec in result.ranked_candidates:
            match = JobCandidateMatch(
                job_id=result.job_id,
                candidate_id=candidate_rec.candidate_id,
                score=candidate_rec.score,
                ranking_details_json=candidate_rec.ranking_details.model_dump(mode='json')
            )
            db.add(match)
        
        db.commit()
        print(f"Stored {len(result.ranked_candidates)} candidate matches for job {result.job_id}")
        
    except Exception as e:
        print(f"Error storing matching results: {e}")
        db.rollback()