"""
Match Details and Candidate Job Matches APIs
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.db.base import get_db
from app.schemas.match import JobCandidateMatchResponse, RankingDetails
from app.crud import candidate as candidate_crud, job as job_crud
from app.models.match import JobCandidateMatch

router = APIRouter(prefix="/matches", tags=["matches"])

@router.get("/{match_id}")
def get_match_details(match_id: int, db: Session = Depends(get_db)):
    """Return full structured match details (overlap, red flags, clarifications, suggestions)"""
    
    # Get match record
    match = db.query(JobCandidateMatch).filter(JobCandidateMatch.id == match_id).first()
    if not match:
        raise HTTPException(status_code=404, detail="Match not found")
    
    # Get candidate and job details
    candidate = candidate_crud.get_candidate(db, match.candidate_id)
    job = job_crud.get_job(db, match.job_id)
    
    if not candidate or not job:
        raise HTTPException(status_code=404, detail="Associated candidate or job not found")
    
    # Parse ranking details
    ranking_details = match.ranking_details_json or {}
    
    try:
        # Validate and structure the ranking details
        structured_details = RankingDetails(
            skills_overlap=ranking_details.get("skills_overlap", {}),
            experience_relevance=ranking_details.get("experience_relevance", {}),
            education_fit=ranking_details.get("education_fit", {}),
            keyword_match=ranking_details.get("keyword_match", {}),
            red_flags=ranking_details.get("red_flags", {}),
            need_clarifications=ranking_details.get("need_clarifications", {}),
            other_role_suggestions=ranking_details.get("other_role_suggestions", {}),
            ai_reasoning=ranking_details.get("ai_reasoning", "No reasoning available")
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing match details: {str(e)}")
    
    return {
        "match_id": match.id,
        "candidate": {
            "id": candidate.id,
            "name": candidate.name,
            "email": candidate.email,
            "phone": candidate.phone
        },
        "job": {
            "id": job.id,
            "title": job.title,
            "department": job.department
        },
        "overall_score": match.score,
        "ranking_details": structured_details,
        "created_at": match.created_at
    }

# Candidate Job Matches API
candidates_router = APIRouter(prefix="/candidates", tags=["candidate-matches"])

@candidates_router.get("/{candidate_id}/matches")
def get_candidate_job_matches(candidate_id: int, db: Session = Depends(get_db)):
    """Show all jobs this candidate was matched to, with scores"""
    
    # Verify candidate exists
    candidate = candidate_crud.get_candidate(db, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")
    
    # Get all matches for this candidate, ordered by score
    matches = db.query(JobCandidateMatch).filter(
        JobCandidateMatch.candidate_id == candidate_id
    ).order_by(JobCandidateMatch.score.desc()).all()
    
    # Format response with job details
    job_matches = []
    for match in matches:
        job = job_crud.get_job(db, match.job_id)
        if job:
            # Extract key insights from ranking details
            ranking_details = match.ranking_details_json or {}
            skills_overlap = ranking_details.get("skills_overlap", {})
            red_flags = ranking_details.get("red_flags", {})
            
            # Count total red flags
            total_red_flags = (
                len(red_flags.get("employment_gaps", [])) +
                len(red_flags.get("irrelevant_experience", [])) +
                len(red_flags.get("missing_qualifications", []))
            )
            
            job_matches.append({
                "match_id": match.id,
                "job_id": job.id,
                "job_title": job.title,
                "department": job.department,
                "score": match.score,
                "skills_match": {
                    "overlap_percentage": skills_overlap.get("overlap_percentage", 0),
                    "matched_skills_count": len(skills_overlap.get("matched_skills", [])),
                    "missing_skills_count": len(skills_overlap.get("missing_skills", []))
                },
                "red_flags_count": total_red_flags,
                "match_quality": "Excellent" if match.score >= 90 else 
                               "Strong" if match.score >= 80 else
                               "Good" if match.score >= 70 else
                               "Moderate" if match.score >= 60 else "Poor",
                "created_at": match.created_at
            })
    
    return {
        "candidate_id": candidate_id,
        "candidate_name": candidate.name,
        "candidate_email": candidate.email,
        "total_job_matches": len(job_matches),
        "job_matches": job_matches
    }