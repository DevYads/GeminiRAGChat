"""
Job API endpoints
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.db.base import get_db
from app.schemas.job import JobResponse, JobCreate, JobSummary
from app.crud import job as job_crud

router = APIRouter(prefix="/jobs", tags=["jobs"])

@router.post("/", response_model=JobResponse)
def create_job(job: JobCreate, db: Session = Depends(get_db)):
    """Create job with description, requirements, keywords"""
    try:
        db_job = job_crud.create_job(db, job)
        return db_job
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating job: {str(e)}")

@router.get("/{job_id}", response_model=JobResponse)
def get_job(job_id: int, db: Session = Depends(get_db)):
    """Fetch job details by ID"""
    job = job_crud.get_job(db, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

@router.get("/", response_model=List[JobSummary])
def list_jobs(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """List all jobs with pagination"""
    jobs = job_crud.get_jobs(db, skip=skip, limit=limit)
    return [
        JobSummary(
            id=job.id,
            title=job.title,
            department=job.department,
            created_at=job.created_at
        ) for job in jobs
    ]

@router.put("/{job_id}", response_model=JobResponse)
def update_job(job_id: int, job_update: dict, db: Session = Depends(get_db)):
    """Update job details"""
    job = job_crud.update_job(db, job_id, job_update)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

@router.delete("/{job_id}")
def delete_job(job_id: int, db: Session = Depends(get_db)):
    """Delete a job"""
    success = job_crud.delete_job(db, job_id)
    if not success:
        raise HTTPException(status_code=404, detail="Job not found")
    return {"message": "Job deleted successfully"}

@router.get("/search/{title_query}", response_model=List[JobSummary])
def search_jobs(title_query: str, db: Session = Depends(get_db)):
    """Search jobs by title"""
    jobs = job_crud.search_jobs_by_title(db, title_query)
    return [
        JobSummary(
            id=job.id,
            title=job.title,
            department=job.department,
            created_at=job.created_at
        ) for job in jobs
    ]