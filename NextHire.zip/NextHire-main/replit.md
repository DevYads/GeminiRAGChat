# NextHire - AI-Powered Recruiting System

## Overview

NextHire is an AI-powered recruiting and candidate ranking system that helps HR teams efficiently match candidates to job positions. The system automates resume parsing, extracts structured candidate data, and uses AI to rank candidates against job descriptions with detailed scoring and recommendations.

The core functionality includes uploading candidate resumes (PDF format), parsing them using Google Gemini AI, storing structured candidate information, and providing intelligent matching between candidates and job positions with comprehensive analysis including skills overlap, experience relevance, and red flag identification.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Framework
The system is built on **FastAPI** with a modular architecture separating concerns into distinct layers:
- API endpoints organized by domain (candidates, jobs, matching)
- CRUD operations abstracted into separate modules
- Business logic encapsulated in service classes
- Database operations handled through SQLAlchemy ORM

### Database Design
Uses **PostgreSQL** as the primary database with **SQLAlchemy** for ORM and **Alembic** for migrations. The schema is designed around three main entities:

**Candidates**: Core candidate information with related tables for experiences, education, skills, and extracted keywords. Supports JSON storage for AI-extracted data.

**Jobs**: Job postings with structured requirements, related skills, and keywords with importance weights.

**Matching**: Stores candidate-job matching results with scores and detailed AI analysis.

### AI Integration
Leverages **Google Gemini 2.5 Flash** for two primary AI workflows:

**Resume Parsing**: Extracts structured data from PDF resumes including personal details, work experience, education, skills, and relevant keywords with normalization.

**Candidate Ranking**: Compares candidate profiles against job descriptions, providing scoring based on skills overlap, experience relevance, education fit, and keyword matching. Includes identification of red flags and clarification needs.

### File Management
Implements local file storage for resume PDFs in the `/uploads` directory with timestamp-based naming to prevent conflicts. Uses `python-multipart` for handling file uploads.

### API Architecture
RESTful API design with:
- Versioned endpoints (`/api/v1/`)
- Domain-specific routers for candidates, jobs, and matching
- Pydantic schemas for request/response validation
- Background task processing for intensive operations
- CORS middleware for cross-origin requests

### Error Handling
Comprehensive error handling with appropriate HTTP status codes and detailed error messages. Graceful fallback mechanisms for AI service failures.

## External Dependencies

### AI Services
- **Google Gemini 2.5 Flash API**: Primary AI service for resume parsing and candidate-job matching analysis
- Requires `GOOGLE_API_KEY` environment variable

### Database
- **PostgreSQL**: Primary database for structured data storage
- Requires `DATABASE_URL` environment variable

### Python Libraries
- **FastAPI**: Web framework and API server
- **SQLAlchemy**: Database ORM and query builder
- **Alembic**: Database migration management
- **Pydantic**: Data validation and serialization
- **PyPDF2**: PDF text extraction for resume parsing
- **python-multipart**: File upload handling
- **uvicorn**: ASGI server for FastAPI

### Infrastructure
- Local file system storage for resume PDFs
- No external cloud storage dependencies
- Self-contained deployment model