"""
NextHire - AI-powered recruiting and candidate ranking system
FastAPI Backend Application
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import os

# Import API routers
from app.api.candidates import router as candidates_router
from app.api.jobs import router as jobs_router
from app.api.matching import router as matching_router
from app.api.hr_workflows import router as hr_workflows_router
from app.api.hr_workflows import analytics_router
from app.api.matches import router as matches_router
from app.api.matches import candidates_router as candidate_matches_router

app = FastAPI(
    title="NextHire API",
    description="AI-powered recruiting and candidate ranking system",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routers
app.include_router(candidates_router, prefix="/api/v1")
app.include_router(jobs_router, prefix="/api/v1")
app.include_router(matching_router, prefix="/api/v1")
# New HR Workflow APIs
app.include_router(hr_workflows_router, prefix="/api/v1")
app.include_router(analytics_router, prefix="/api/v1")
app.include_router(matches_router, prefix="/api/v1")
app.include_router(candidate_matches_router, prefix="/api/v1")

@app.get("/")
def read_root():
    return {
        "message": "NextHire API is running!", 
        "version": "1.0.0",
        "endpoints": {
            "candidates": "/api/v1/candidates",
            "jobs": "/api/v1/jobs",
            "matching": "/api/v1/jobs/{job_id}/match",
            "recommendations": "/api/v1/jobs/{job_id}/recommendations",
            "hr_workflows": {
                "single_candidate_match": "/api/v1/jobs/{job_id}/candidates/upload",
                "job_candidate_rankings": "/api/v1/jobs/{job_id}/matches",
                "match_details": "/api/v1/matches/{match_id}",
                "candidate_job_matches": "/api/v1/candidates/{candidate_id}/matches"
            },
            "analytics": {
                "top_candidates": "/api/v1/analytics/top-candidates?job_id=...",
                "red_flags": "/api/v1/analytics/red-flags?job_id=...",
                "job_suggestions": "/api/v1/analytics/suggestions?candidate_id=..."
            }
        }
    }

@app.get("/health")
def health_check():
    return {"status": "healthy", "database": "connected"}

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=5000,
        reload=True
    )